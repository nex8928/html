package com.loanorigination.controller;

import com.loanorigination.dto.LoginRequest;
import com.loanorigination.dto.LoginResponse;
import com.loanorigination.dto.LogoutResponse;
import com.loanorigination.dto.RegisterRequest;
import com.loanorigination.dto.UserProfileResponse;
import com.loanorigination.dto.ErrorResponse;
import com.loanorigination.service.AuthService;
import com.loanorigination.exception.AuthenticationException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"}, 
             allowedHeaders = "*", 
             methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
@Tag(name = "Authentication", description = "Authentication APIs for customers and bank members")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/customer/register")
    @Operation(summary = "Register new customer", 
               description = "Creates a new customer account in the loan origination system")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Customer registered successfully",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = LoginResponse.class))),
        @ApiResponse(responseCode = "400", description = "Registration failed - validation errors or duplicate username",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(responseCode = "401", description = "Authentication error",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = ErrorResponse.class)))
    })
    public ResponseEntity<?> registerCustomer(@Valid @RequestBody RegisterRequest registerRequest, 
                                            BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return ResponseEntity.badRequest().body(createValidationErrorResponse(bindingResult));
        }
        
        try {
            LoginResponse response = authService.registerCustomer(registerRequest);
            return ResponseEntity.ok(response);
        } catch (AuthenticationException e) {
            ErrorResponse errorResponse = new ErrorResponse(e.getMessage(), "REGISTRATION_FAILED", 400);
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @PostMapping("/customer/login")
    @Operation(summary = "Customer login", 
               description = "Authenticates a customer and returns JWT token with redirect URL")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Login successful",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = LoginResponse.class))),
        @ApiResponse(responseCode = "400", description = "Validation errors",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(responseCode = "401", description = "Login failed - invalid credentials",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = ErrorResponse.class)))
    })
    public ResponseEntity<?> loginCustomer(@Valid @RequestBody LoginRequest loginRequest, 
                                         BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return ResponseEntity.badRequest().body(createValidationErrorResponse(bindingResult));
        }
        
        try {
            LoginResponse response = authService.loginCustomer(loginRequest);
            return ResponseEntity.ok(response);
        } catch (AuthenticationException e) {
            ErrorResponse errorResponse = new ErrorResponse(e.getMessage(), "AUTHENTICATION_FAILED", 401);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }
    }

    @PostMapping("/member/login")
    @Operation(summary = "Member login", 
               description = "Authenticates a bank member (maker/checker) and returns JWT token with redirect URL")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Login successful",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = LoginResponse.class))),
        @ApiResponse(responseCode = "400", description = "Validation errors",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(responseCode = "401", description = "Login failed - invalid credentials",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = ErrorResponse.class)))
    })
    public ResponseEntity<?> loginMember(@Valid @RequestBody LoginRequest loginRequest, 
                                       BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return ResponseEntity.badRequest().body(createValidationErrorResponse(bindingResult));
        }
        
        try {
            LoginResponse response = authService.loginMember(loginRequest);
            return ResponseEntity.ok(response);
        } catch (AuthenticationException e) {
            ErrorResponse errorResponse = new ErrorResponse(e.getMessage(), "AUTHENTICATION_FAILED", 401);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }
    }

    @GetMapping("/profile")
    @Operation(summary = "Get user profile", 
               description = "Returns the profile information of the authenticated user")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Profile retrieved successfully",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = UserProfileResponse.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized - invalid or missing token",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = ErrorResponse.class)))
    })
    public ResponseEntity<?> getUserProfile(HttpServletRequest request) {
        try {
            UserProfileResponse profile = authService.getUserProfile(request);
            return ResponseEntity.ok(profile);
        } catch (AuthenticationException e) {
            ErrorResponse errorResponse = new ErrorResponse(e.getMessage(), "UNAUTHORIZED", 401);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }
    }

    @PostMapping("/logout")
    @Operation(summary = "User logout", 
               description = "Logs out the authenticated user and invalidates the JWT token")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Logout successful",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = LogoutResponse.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized - invalid or missing token",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = ErrorResponse.class)))
    })
    public ResponseEntity<?> logout(HttpServletRequest request) {
        try {
            LogoutResponse response = authService.logout(request);
            return ResponseEntity.ok(response);
        } catch (AuthenticationException e) {
            ErrorResponse errorResponse = new ErrorResponse(e.getMessage(), "LOGOUT_FAILED", 401);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }
    }

    @PostMapping("/refresh")
    @Operation(summary = "Refresh JWT token", 
               description = "Generates a new JWT token using the current valid token")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Token refreshed successfully",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = LoginResponse.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized - invalid or missing token",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = ErrorResponse.class)))
    })
    public ResponseEntity<?> refreshToken(HttpServletRequest request) {
        try {
            LoginResponse response = authService.refreshToken(request);
            return ResponseEntity.ok(response);
        } catch (AuthenticationException e) {
            ErrorResponse errorResponse = new ErrorResponse(e.getMessage(), "TOKEN_REFRESH_FAILED", 401);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }
    }

    @GetMapping("/validate")
    @Operation(summary = "Validate JWT token", 
               description = "Validates if the provided JWT token is still valid")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Token validation result"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - invalid or missing token")
    })
    public ResponseEntity<?> validateToken(HttpServletRequest request) {
        String token = extractTokenFromRequest(request);
        boolean isValid = authService.isTokenValid(token);
        
        Map<String, Object> response = new HashMap<>();
        response.put("valid", isValid);
        response.put("timestamp", LocalDateTime.now());
        
        if (isValid) {
            return ResponseEntity.ok(response);
        } else {
            response.put("error", "Invalid or expired token");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
    }

    // Helper methods
    private ErrorResponse createValidationErrorResponse(BindingResult bindingResult) {
        StringBuilder errorMessage = new StringBuilder("Validation failed: ");
        bindingResult.getFieldErrors().forEach(error -> 
            errorMessage.append(error.getField()).append(" - ").append(error.getDefaultMessage()).append("; ")
        );
        return new ErrorResponse(errorMessage.toString(), "VALIDATION_ERROR", 400);
    }

    private String extractTokenFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }
}

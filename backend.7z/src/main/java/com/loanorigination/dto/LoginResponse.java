package com.loanorigination.dto;

public class LoginResponse {
    
    private String token;
    private String userType;
    private String username;
    private Boolean isNewUser;
    private String redirectUrl;
    private String message;
    
    // Constructors
    public LoginResponse() {}
    
    public LoginResponse(String token, String userType, String username, Boolean isNewUser) {
        this.token = token;
        this.userType = userType;
        this.username = username;
        this.isNewUser = isNewUser;
        this.redirectUrl = generateRedirectUrl(userType, isNewUser);
        this.message = "Login successful";
    }
    
    public LoginResponse(String token, String userType, String username, Boolean isNewUser, String redirectUrl) {
        this.token = token;
        this.userType = userType;
        this.username = username;
        this.isNewUser = isNewUser;
        this.redirectUrl = redirectUrl;
        this.message = "Login successful";
    }
    
    private String generateRedirectUrl(String userType, Boolean isNewUser) {
        if ("CUSTOMER".equals(userType)) {
            return isNewUser ? "/customer/profile-setup" : "/customer/dashboard";
        } else {
            return "/member/dashboard";
        }
    }
    
    // Getters and Setters
    public String getToken() {
        return token;
    }
    
    public void setToken(String token) {
        this.token = token;
    }
    
    public String getUserType() {
        return userType;
    }
    
    public void setUserType(String userType) {
        this.userType = userType;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public Boolean getIsNewUser() {
        return isNewUser;
    }
    
    public void setIsNewUser(Boolean isNewUser) {
        this.isNewUser = isNewUser;
    }
    
    public String getRedirectUrl() {
        return redirectUrl;
    }
    
    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
}

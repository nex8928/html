package com.loanorigination.dto;

public class UserProfileResponse {
    
    private String username;
    private String userType;
    private Boolean isNewUser;
    private String role; // For members only
    
    public UserProfileResponse() {}
    
    public UserProfileResponse(String username, String userType, Boolean isNewUser) {
        this.username = username;
        this.userType = userType;
        this.isNewUser = isNewUser;
    }
    
    public UserProfileResponse(String username, String userType, Boolean isNewUser, String role) {
        this.username = username;
        this.userType = userType;
        this.isNewUser = isNewUser;
        this.role = role;
    }
    
    // Getters and Setters
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getUserType() {
        return userType;
    }
    
    public void setUserType(String userType) {
        this.userType = userType;
    }
    
    public Boolean getIsNewUser() {
        return isNewUser;
    }
    
    public void setIsNewUser(Boolean isNewUser) {
        this.isNewUser = isNewUser;
    }
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
}
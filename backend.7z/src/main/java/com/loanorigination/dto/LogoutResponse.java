package com.loanorigination.dto;

public class LogoutResponse {
    
    private String message;
    private String redirectUrl;
    private boolean success;
    
    // Constructors
    public LogoutResponse() {}
    
    public LogoutResponse(String message, String redirectUrl, boolean success) {
        this.message = message;
        this.redirectUrl = redirectUrl;
        this.success = success;
    }
    
    public LogoutResponse(boolean success) {
        this.success = success;
        this.message = success ? "Logout successful" : "Logout failed";
        this.redirectUrl = "/";
    }
    
    // Getters and Setters
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getRedirectUrl() {
        return redirectUrl;
    }
    
    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }
    
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
}
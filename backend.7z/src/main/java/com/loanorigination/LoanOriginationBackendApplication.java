package com.loanorigination;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanOriginationBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanOriginationBackendApplication.class, args);
	}

}

package com.loanorigination.service;

import com.loanorigination.dto.LoginRequest;
import com.loanorigination.dto.LoginResponse;
import com.loanorigination.dto.LogoutResponse;
import com.loanorigination.dto.RegisterRequest;
import com.loanorigination.dto.UserProfileResponse;
import com.loanorigination.entity.User;
import com.loanorigination.entity.Member;
import com.loanorigination.exception.AuthenticationException;
import com.loanorigination.repository.UserRepository;
import com.loanorigination.repository.MemberRepository;
import com.loanorigination.security.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;
    
    // Simple token blacklist for logout functionality
    private final Set<String> blacklistedTokens = ConcurrentHashMap.newKeySet();

    public LoginResponse registerCustomer(RegisterRequest registerRequest) {
        if (userRepository.existsByUsername(registerRequest.getUsername())) {
            throw new AuthenticationException("Username already exists");
        }

        // Basic password validation
        if (registerRequest.getPassword().length() < 6) {
            throw new AuthenticationException("Password must be at least 6 characters long");
        }

        User user = new User();
        user.setUsername(registerRequest.getUsername());
        user.setPasswordHash(passwordEncoder.encode(registerRequest.getPassword()));
        user.setIsNewUser(true);
        user.setActivationAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        user = userRepository.save(user);

        String token = jwtUtil.generateToken(user.getUsername(), "CUSTOMER");
        return new LoginResponse(token, "CUSTOMER", user.getUsername(), user.getIsNewUser());
    }

    public LoginResponse loginCustomer(LoginRequest loginRequest) {
        // Validate input
        if (!StringUtils.hasText(loginRequest.getUsername()) || !StringUtils.hasText(loginRequest.getPassword())) {
            throw new AuthenticationException("Username and password are required");
        }

        Optional<User> userOptional = userRepository.findByUsername(loginRequest.getUsername().trim());
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("Invalid username or password");
        }

        User user = userOptional.get();
        if (!passwordEncoder.matches(loginRequest.getPassword(), user.getPasswordHash())) {
            throw new AuthenticationException("Invalid username or password");
        }

        // Update last login time
        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);

        String token = jwtUtil.generateToken(user.getUsername(), "CUSTOMER");
        return new LoginResponse(token, "CUSTOMER", user.getUsername(), user.getIsNewUser());
    }

    public LoginResponse loginMember(LoginRequest loginRequest) {
        // Validate input
        if (!StringUtils.hasText(loginRequest.getUsername()) || !StringUtils.hasText(loginRequest.getPassword())) {
            throw new AuthenticationException("Username and password are required");
        }

        Optional<Member> memberOptional = memberRepository.findByUsername(loginRequest.getUsername().trim());
        if (memberOptional.isEmpty()) {
            throw new AuthenticationException("Invalid username or password");
        }

        Member member = memberOptional.get();
        if (!passwordEncoder.matches(loginRequest.getPassword(), member.getPasswordHash())) {
            throw new AuthenticationException("Invalid username or password");
        }

        String token = jwtUtil.generateToken(member.getUsername(), member.getRole().getRoleName());
        return new LoginResponse(token, member.getRole().getRoleName(), member.getUsername(), false);
    }

    public UserProfileResponse getUserProfile(HttpServletRequest request) {
        String token = extractTokenFromRequest(request);
        if (token == null || isTokenBlacklisted(token) || !jwtUtil.validateToken(token)) {
            throw new AuthenticationException("Invalid or missing token");
        }

        String username = jwtUtil.extractUsername(token);
        String userType = jwtUtil.extractUserType(token);

        if ("CUSTOMER".equals(userType)) {
            Optional<User> userOptional = userRepository.findByUsername(username);
            if (userOptional.isPresent()) {
                User user = userOptional.get();
                return new UserProfileResponse(user.getUsername(), "CUSTOMER", user.getIsNewUser());
            }
        } else {
            Optional<Member> memberOptional = memberRepository.findByUsername(username);
            if (memberOptional.isPresent()) {
                Member member = memberOptional.get();
                return new UserProfileResponse(member.getUsername(), userType, false, member.getRole().getRoleName());
            }
        }

        throw new AuthenticationException("User not found");
    }
    
    public LogoutResponse logout(HttpServletRequest request) {
        String token = extractTokenFromRequest(request);
        if (token == null) {
            throw new AuthenticationException("No token provided");
        }
        
        // Add token to blacklist
        blacklistedTokens.add(token);
        
        // Determine redirect URL based on user type
        String redirectUrl = "/";
        try {
            String userType = jwtUtil.extractUserType(token);
            if ("CUSTOMER".equals(userType)) {
                redirectUrl = "/customer/login";
            } else {
                redirectUrl = "/member/login";
            }
        } catch (Exception e) {
            // If token is invalid, use default redirect
        }
        
        return new LogoutResponse("Logout successful", redirectUrl, true);
    }
    
    public LoginResponse refreshToken(HttpServletRequest request) {
        String token = extractTokenFromRequest(request);
        if (token == null || isTokenBlacklisted(token) || !jwtUtil.validateToken(token)) {
            throw new AuthenticationException("Invalid or missing token");
        }
        
        String username = jwtUtil.extractUsername(token);
        String userType = jwtUtil.extractUserType(token);
        
        // Blacklist the old token
        blacklistedTokens.add(token);
        
        // Generate new token
        String newToken = jwtUtil.generateToken(username, userType);
        
        // Determine if user is new (only for customers)
        Boolean isNewUser = false;
        if ("CUSTOMER".equals(userType)) {
            Optional<User> userOptional = userRepository.findByUsername(username);
            if (userOptional.isPresent()) {
                isNewUser = userOptional.get().getIsNewUser();
            }
        }
        
        return new LoginResponse(newToken, userType, username, isNewUser);
    }
    
    public boolean isTokenValid(String token) {
        return token != null && !isTokenBlacklisted(token) && jwtUtil.validateToken(token);
    }
    
    private boolean isTokenBlacklisted(String token) {
        return blacklistedTokens.contains(token);
    }

    private String extractTokenFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }
}

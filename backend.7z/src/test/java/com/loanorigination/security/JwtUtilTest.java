package com.loanorigination.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;

class JwtUtilTest {

    private JwtUtil jwtUtil;

    @BeforeEach
    void setUp() {
        jwtUtil = new JwtUtil();
        // Set test values using reflection
        ReflectionTestUtils.setField(jwtUtil, "secret", "mySecretKey123456789012345678901234567890");
        ReflectionTestUtils.setField(jwtUtil, "expiration", 86400000L); // 24 hours
    }

    @Test
    void testGenerateTokenForCustomer() {
        String username = "testcustomer";
        String userType = "CUSTOMER";
        
        String token = jwtUtil.generateToken(username, userType);
        
        assertNotNull(token);
        assertFalse(token.isEmpty());
    }

    @Test
    void testGenerateTokenForMember() {
        String username = "testmember";
        String userType = "MAKER";
        
        String token = jwtUtil.generateToken(username, userType);
        
        assertNotNull(token);
        assertFalse(token.isEmpty());
    }

    @Test
    void testExtractUsername() {
        String username = "testuser";
        String userType = "CUSTOMER";
        String token = jwtUtil.generateToken(username, userType);
        
        String extractedUsername = jwtUtil.extractUsername(token);
        
        assertEquals(username, extractedUsername);
    }

    @Test
    void testExtractUserType() {
        String username = "testuser";
        String userType = "CUSTOMER";
        String token = jwtUtil.generateToken(username, userType);
        
        String extractedUserType = jwtUtil.extractUserType(token);
        
        assertEquals(userType, extractedUserType);
    }

    @Test
    void testExtractRole() {
        String username = "testmember";
        String userType = "MAKER";
        String token = jwtUtil.generateToken(username, userType);
        
        String extractedRole = jwtUtil.extractRole(token);
        
        assertEquals(userType, extractedRole);
    }

    @Test
    void testValidateTokenWithUsername() {
        String username = "testuser";
        String userType = "CUSTOMER";
        String token = jwtUtil.generateToken(username, userType);
        
        Boolean isValid = jwtUtil.validateToken(token, username);
        
        assertTrue(isValid);
    }

    @Test
    void testValidateTokenWithoutUsername() {
        String username = "testuser";
        String userType = "CUSTOMER";
        String token = jwtUtil.generateToken(username, userType);
        
        Boolean isValid = jwtUtil.validateToken(token);
        
        assertTrue(isValid);
    }

    @Test
    void testValidateTokenWithWrongUsername() {
        String username = "testuser";
        String userType = "CUSTOMER";
        String token = jwtUtil.generateToken(username, userType);
        
        Boolean isValid = jwtUtil.validateToken(token, "wronguser");
        
        assertFalse(isValid);
    }

    @Test
    void testValidateInvalidToken() {
        String invalidToken = "invalid.token.here";
        
        Boolean isValid = jwtUtil.validateToken(invalidToken);
        
        assertFalse(isValid);
    }

    @Test
    void testRefreshToken() {
        String username = "testuser";
        String userType = "CUSTOMER";
        String originalToken = jwtUtil.generateToken(username, userType);
        
        String refreshedToken = jwtUtil.refreshToken(originalToken);
        
        assertNotNull(refreshedToken);
        // Test that the refreshed token contains the same user data
        assertEquals(username, jwtUtil.extractUsername(refreshedToken));
        assertEquals(userType, jwtUtil.extractUserType(refreshedToken));
        // Test that the refreshed token is valid
        assertTrue(jwtUtil.validateToken(refreshedToken));
    }

    @Test
    void testIsTokenExpired() {
        String username = "testuser";
        String userType = "CUSTOMER";
        String token = jwtUtil.generateToken(username, userType);
        
        Boolean isExpired = jwtUtil.isTokenExpired(token);
        
        assertFalse(isExpired);
    }
}
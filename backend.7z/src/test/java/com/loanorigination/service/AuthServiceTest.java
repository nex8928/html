package com.loanorigination.service;

import com.loanorigination.dto.LoginRequest;
import com.loanorigination.dto.LoginResponse;
import com.loanorigination.dto.LogoutResponse;
import com.loanorigination.dto.UserProfileResponse;
import com.loanorigination.entity.Member;
import com.loanorigination.entity.Role;
import com.loanorigination.entity.User;
import com.loanorigination.exception.AuthenticationException;
import com.loanorigination.repository.MemberRepository;
import com.loanorigination.repository.UserRepository;
import com.loanorigination.security.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private MemberRepository memberRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private HttpServletRequest request;

    @InjectMocks
    private AuthService authService;

    private User testUser;
    private Member testMember;
    private Role testRole;
    private LoginRequest loginRequest;

    @BeforeEach
    void setUp() {
        // Setup test user
        testUser = new User();
        testUser.setCustomerId(1L);
        testUser.setUsername("testcustomer");
        testUser.setPasswordHash("hashedpassword");
        testUser.setIsNewUser(true);
        testUser.setActivationAt(LocalDateTime.now());
        testUser.setUpdatedAt(LocalDateTime.now());

        // Setup test role
        testRole = new Role();
        testRole.setId(1L);
        testRole.setRoleName("MAKER");

        // Setup test member
        testMember = new Member();
        testMember.setMemberId(1L);
        testMember.setUsername("testmember");
        testMember.setPasswordHash("hashedpassword");
        testMember.setRole(testRole);

        // Setup login request
        loginRequest = new LoginRequest();
        loginRequest.setUsername("testuser");
        loginRequest.setPassword("password123");
    }

    @Test
    void testLoginCustomerSuccess() {
        // Arrange
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches("password123", "hashedpassword")).thenReturn(true);
        when(jwtUtil.generateToken("testcustomer", "CUSTOMER")).thenReturn("jwt-token");
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        // Act
        LoginResponse response = authService.loginCustomer(loginRequest);

        // Assert
        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
        assertEquals("CUSTOMER", response.getUserType());
        assertEquals("testcustomer", response.getUsername());
        assertTrue(response.getIsNewUser());
        assertEquals("/customer/profile-setup", response.getRedirectUrl());
        assertEquals("Login successful", response.getMessage());

        verify(userRepository).save(any(User.class));
    }

    @Test
    void testLoginCustomerInvalidUsername() {
        // Arrange
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.empty());

        // Act & Assert
        AuthenticationException exception = assertThrows(
                AuthenticationException.class,
                () -> authService.loginCustomer(loginRequest));
        assertEquals("Invalid username or password", exception.getMessage());
    }

    @Test
    void testLoginCustomerInvalidPassword() {
        // Arrange
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches("password123", "hashedpassword")).thenReturn(false);

        // Act & Assert
        AuthenticationException exception = assertThrows(
                AuthenticationException.class,
                () -> authService.loginCustomer(loginRequest));
        assertEquals("Invalid username or password", exception.getMessage());
    }

    @Test
    void testLoginCustomerEmptyCredentials() {
        // Arrange
        loginRequest.setUsername("");
        loginRequest.setPassword("");

        // Act & Assert
        AuthenticationException exception = assertThrows(
                AuthenticationException.class,
                () -> authService.loginCustomer(loginRequest));
        assertEquals("Username and password are required", exception.getMessage());
    }

    @Test
    void testLoginMemberSuccess() {
        // Arrange
        when(memberRepository.findByUsername("testuser")).thenReturn(Optional.of(testMember));
        when(passwordEncoder.matches("password123", "hashedpassword")).thenReturn(true);
        when(jwtUtil.generateToken("testmember", "MAKER")).thenReturn("jwt-token");

        // Act
        LoginResponse response = authService.loginMember(loginRequest);

        // Assert
        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
        assertEquals("MAKER", response.getUserType());
        assertEquals("testmember", response.getUsername());
        assertFalse(response.getIsNewUser());
        assertEquals("/member/dashboard", response.getRedirectUrl());
    }

    @Test
    void testLoginMemberInvalidCredentials() {
        // Arrange
        when(memberRepository.findByUsername("testuser")).thenReturn(Optional.empty());

        // Act & Assert
        AuthenticationException exception = assertThrows(
                AuthenticationException.class,
                () -> authService.loginMember(loginRequest));
        assertEquals("Invalid username or password", exception.getMessage());
    }

    @Test
    void testGetUserProfileCustomer() {
        // Arrange
        when(request.getHeader("Authorization")).thenReturn("Bearer jwt-token");
        when(jwtUtil.validateToken("jwt-token")).thenReturn(true);
        when(jwtUtil.extractUsername("jwt-token")).thenReturn("testcustomer");
        when(jwtUtil.extractUserType("jwt-token")).thenReturn("CUSTOMER");
        when(userRepository.findByUsername("testcustomer")).thenReturn(Optional.of(testUser));

        // Act
        UserProfileResponse response = authService.getUserProfile(request);

        // Assert
        assertNotNull(response);
        assertEquals("testcustomer", response.getUsername());
        assertEquals("CUSTOMER", response.getUserType());
        assertTrue(response.getIsNewUser());
    }

    @Test
    void testGetUserProfileMember() {
        // Arrange
        when(request.getHeader("Authorization")).thenReturn("Bearer jwt-token");
        when(jwtUtil.validateToken("jwt-token")).thenReturn(true);
        when(jwtUtil.extractUsername("jwt-token")).thenReturn("testmember");
        when(jwtUtil.extractUserType("jwt-token")).thenReturn("MAKER");
        when(memberRepository.findByUsername("testmember")).thenReturn(Optional.of(testMember));

        // Act
        UserProfileResponse response = authService.getUserProfile(request);

        // Assert
        assertNotNull(response);
        assertEquals("testmember", response.getUsername());
        assertEquals("MAKER", response.getUserType());
        assertFalse(response.getIsNewUser());
        assertEquals("MAKER", response.getRole());
    }

    @Test
    void testGetUserProfileInvalidToken() {
        // Arrange
        when(request.getHeader("Authorization")).thenReturn("Bearer invalid-token");
        when(jwtUtil.validateToken("invalid-token")).thenReturn(false);

        // Act & Assert
        AuthenticationException exception = assertThrows(
                AuthenticationException.class,
                () -> authService.getUserProfile(request));
        assertEquals("Invalid or missing token", exception.getMessage());
    }

    @Test
    void testLogoutSuccess() {
        // Arrange
        when(request.getHeader("Authorization")).thenReturn("Bearer jwt-token");
        when(jwtUtil.extractUserType("jwt-token")).thenReturn("CUSTOMER");

        // Act
        LogoutResponse response = authService.logout(request);

        // Assert
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals("Logout successful", response.getMessage());
        assertEquals("/customer/login", response.getRedirectUrl());
    }

    @Test
    void testLogoutNoToken() {
        // Arrange
        when(request.getHeader("Authorization")).thenReturn(null);

        // Act & Assert
        AuthenticationException exception = assertThrows(
                AuthenticationException.class,
                () -> authService.logout(request));
        assertEquals("No token provided", exception.getMessage());
    }

    @Test
    void testRefreshTokenSuccess() {
        // Arrange
        when(request.getHeader("Authorization")).thenReturn("Bearer jwt-token");
        when(jwtUtil.validateToken("jwt-token")).thenReturn(true);
        when(jwtUtil.extractUsername("jwt-token")).thenReturn("testcustomer");
        when(jwtUtil.extractUserType("jwt-token")).thenReturn("CUSTOMER");
        when(jwtUtil.generateToken("testcustomer", "CUSTOMER")).thenReturn("new-jwt-token");
        when(userRepository.findByUsername("testcustomer")).thenReturn(Optional.of(testUser));

        // Act
        LoginResponse response = authService.refreshToken(request);

        // Assert
        assertNotNull(response);
        assertEquals("new-jwt-token", response.getToken());
        assertEquals("CUSTOMER", response.getUserType());
        assertEquals("testcustomer", response.getUsername());
        assertTrue(response.getIsNewUser());
    }

    @Test
    void testIsTokenValidTrue() {
        // Arrange
        when(jwtUtil.validateToken("valid-token")).thenReturn(true);

        // Act
        boolean isValid = authService.isTokenValid("valid-token");

        // Assert
        assertTrue(isValid);
    }

    @Test
    void testIsTokenValidFalse() {
        // Arrange
        when(jwtUtil.validateToken("invalid-token")).thenReturn(false);

        // Act
        boolean isValid = authService.isTokenValid("invalid-token");

        // Assert
        assertFalse(isValid);
    }

    @Test
    void testIsTokenValidNull() {
        // Act
        boolean isValid = authService.isTokenValid(null);

        // Assert
        assertFalse(isValid);
    }
}
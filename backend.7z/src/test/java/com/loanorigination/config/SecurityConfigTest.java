package com.loanorigination.config;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class SecurityConfigTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testPublicEndpointsAreAccessible() throws Exception {
        // Test customer login endpoint - should be accessible without authentication
        // Returns 400 for validation error (password too short), not 401/403 for
        // security
        mockMvc.perform(post("/api/auth/customer/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"username\":\"test\",\"password\":\"test\"}"))
                .andExpect(status().isBadRequest()); // 400 for validation error, not 401/403

        // Test member login endpoint - should be accessible without authentication
        // Returns 400 for validation error (password too short), not 401/403 for
        // security
        mockMvc.perform(post("/api/auth/member/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"username\":\"test\",\"password\":\"test\"}"))
                .andExpect(status().isBadRequest()); // 400 for validation error, not 401/403

        // Test logout endpoint - returns 401 because it requires authentication
        mockMvc.perform(post("/api/auth/logout"))
                .andExpect(status().isUnauthorized()); // Requires authentication
    }

    @Test
    public void testProtectedEndpointsRequireAuthentication() throws Exception {
        // Test customer endpoint without authentication - should return 401
        mockMvc.perform(get("/api/customer/profile"))
                .andExpect(status().isUnauthorized())
                .andExpect(content().json(
                        "{\"error\":\"AUTHENTICATION_REQUIRED\",\"message\":\"Authentication required to access this resource\"}"));

        // Test member endpoint without authentication - should return 401
        mockMvc.perform(get("/api/member/applications"))
                .andExpect(status().isUnauthorized())
                .andExpect(content().json(
                        "{\"error\":\"AUTHENTICATION_REQUIRED\",\"message\":\"Authentication required to access this resource\"}"));
    }

    @Test
    public void testCorsConfiguration() throws Exception {
        // Test CORS preflight request from TempWork frontend
        mockMvc.perform(options("/api/auth/customer/login")
                .header("Origin", "http://localhost:3000")
                .header("Access-Control-Request-Method", "POST")
                .header("Access-Control-Request-Headers", "Authorization,Content-Type"))
                .andExpect(status().isOk())
                .andExpect(header().string("Access-Control-Allow-Origin", "http://localhost:3000"))
                .andExpect(header().string("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,PATCH"))
                .andExpect(header().string("Access-Control-Allow-Credentials", "true"));
    }

    @Test
    public void testInvalidTokenHandling() throws Exception {
        // Test with malformed token - should return 401 with error message
        mockMvc.perform(get("/api/customer/profile")
                .header("Authorization", "Bearer invalid-token"))
                .andExpect(status().isUnauthorized())
                .andExpect(
                        content().json("{\"error\":\"INVALID_TOKEN\",\"message\":\"Invalid or malformed JWT token\"}"));
    }

    @Test
    public void testSwaggerEndpointsArePublic() throws Exception {
        // Test Swagger endpoints are accessible without authentication
        mockMvc.perform(get("/v3/api-docs"))
                .andExpect(status().isOk());
    }

    @Test
    public void testRoleBasedEndpointConfiguration() throws Exception {
        // Test that customer endpoints require CUSTOMER role (returns 401 without auth)
        mockMvc.perform(get("/api/customer/profile"))
                .andExpect(status().isUnauthorized());

        // Test that member endpoints require MAKER/CHECKER role (returns 401 without
        // auth)
        mockMvc.perform(get("/api/member/dashboard"))
                .andExpect(status().isUnauthorized());

        // Test that admin endpoints require CHECKER role (returns 401 without auth)
        mockMvc.perform(get("/api/admin/users"))
                .andExpect(status().isUnauthorized());
    }
}
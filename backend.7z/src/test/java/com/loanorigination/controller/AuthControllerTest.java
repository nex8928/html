package com.loanorigination.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.loanorigination.dto.LoginRequest;
import com.loanorigination.dto.LoginResponse;
import com.loanorigination.dto.LogoutResponse;
import com.loanorigination.dto.UserProfileResponse;
import com.loanorigination.exception.AuthenticationException;
import com.loanorigination.service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityFilterAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = AuthController.class, excludeAutoConfiguration = { SecurityAutoConfiguration.class,
        SecurityFilterAutoConfiguration.class })
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthService authService;

    @Autowired
    private ObjectMapper objectMapper;

    private LoginRequest loginRequest;
    private LoginResponse loginResponse;
    private UserProfileResponse userProfileResponse;
    private LogoutResponse logoutResponse;

    @BeforeEach
    void setUp() {
        loginRequest = new LoginRequest();
        loginRequest.setUsername("testuser");
        loginRequest.setPassword("password123");

        loginResponse = new LoginResponse();
        loginResponse.setToken("jwt-token");
        loginResponse.setUserType("CUSTOMER");
        loginResponse.setUsername("testuser");
        loginResponse.setIsNewUser(true);
        loginResponse.setRedirectUrl("/customer/profile-setup");
        loginResponse.setMessage("Login successful");

        userProfileResponse = new UserProfileResponse();
        userProfileResponse.setUsername("testuser");
        userProfileResponse.setUserType("CUSTOMER");
        userProfileResponse.setIsNewUser(true);

        logoutResponse = new LogoutResponse();
        logoutResponse.setSuccess(true);
        logoutResponse.setMessage("Logout successful");
        logoutResponse.setRedirectUrl("/customer/login");
    }

    @Test
    void testCustomerLoginSuccess() throws Exception {
        when(authService.loginCustomer(any(LoginRequest.class))).thenReturn(loginResponse);

        mockMvc.perform(post("/api/auth/customer/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.token").value("jwt-token"))
                .andExpect(jsonPath("$.userType").value("CUSTOMER"))
                .andExpect(jsonPath("$.username").value("testuser"))
                .andExpect(jsonPath("$.isNewUser").value(true))
                .andExpect(jsonPath("$.redirectUrl").value("/customer/profile-setup"))
                .andExpect(jsonPath("$.message").value("Login successful"));
    }

    @Test
    void testCustomerLoginInvalidCredentials() throws Exception {
        when(authService.loginCustomer(any(LoginRequest.class)))
                .thenThrow(new AuthenticationException("Invalid username or password"));

        mockMvc.perform(post("/api/auth/customer/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value("Invalid username or password"))
                .andExpect(jsonPath("$.error").value("AUTHENTICATION_FAILED"))
                .andExpect(jsonPath("$.status").value(401));
    }

    @Test
    void testCustomerLoginValidationError() throws Exception {
        LoginRequest invalidRequest = new LoginRequest();
        invalidRequest.setUsername(""); // Invalid - too short
        invalidRequest.setPassword("123"); // Invalid - too short

        mockMvc.perform(post("/api/auth/customer/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.error").value("VALIDATION_ERROR"))
                .andExpect(jsonPath("$.status").value(400));
    }

    @Test
    void testMemberLoginSuccess() throws Exception {
        LoginResponse memberResponse = new LoginResponse();
        memberResponse.setToken("jwt-token");
        memberResponse.setUserType("MAKER");
        memberResponse.setUsername("testmember");
        memberResponse.setIsNewUser(false);
        memberResponse.setRedirectUrl("/member/dashboard");
        memberResponse.setMessage("Login successful");

        when(authService.loginMember(any(LoginRequest.class))).thenReturn(memberResponse);

        mockMvc.perform(post("/api/auth/member/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.token").value("jwt-token"))
                .andExpect(jsonPath("$.userType").value("MAKER"))
                .andExpect(jsonPath("$.username").value("testmember"))
                .andExpect(jsonPath("$.isNewUser").value(false))
                .andExpect(jsonPath("$.redirectUrl").value("/member/dashboard"));
    }

    @Test
    void testMemberLoginInvalidCredentials() throws Exception {
        when(authService.loginMember(any(LoginRequest.class)))
                .thenThrow(new AuthenticationException("Invalid username or password"));

        mockMvc.perform(post("/api/auth/member/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Invalid username or password"))
                .andExpect(jsonPath("$.error").value("AUTHENTICATION_FAILED"));
    }

    @Test
    void testGetUserProfileSuccess() throws Exception {
        when(authService.getUserProfile(any())).thenReturn(userProfileResponse);

        mockMvc.perform(get("/api/auth/profile")
                .header("Authorization", "Bearer jwt-token"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.username").value("testuser"))
                .andExpect(jsonPath("$.userType").value("CUSTOMER"))
                .andExpect(jsonPath("$.isNewUser").value(true));
    }

    @Test
    void testGetUserProfileUnauthorized() throws Exception {
        when(authService.getUserProfile(any()))
                .thenThrow(new AuthenticationException("Invalid or missing token"));

        mockMvc.perform(get("/api/auth/profile")
                .header("Authorization", "Bearer invalid-token"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Invalid or missing token"))
                .andExpect(jsonPath("$.error").value("UNAUTHORIZED"));
    }

    @Test
    void testLogoutSuccess() throws Exception {
        when(authService.logout(any())).thenReturn(logoutResponse);

        mockMvc.perform(post("/api/auth/logout")
                .header("Authorization", "Bearer jwt-token"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Logout successful"))
                .andExpect(jsonPath("$.redirectUrl").value("/customer/login"));
    }

    @Test
    void testLogoutUnauthorized() throws Exception {
        when(authService.logout(any()))
                .thenThrow(new AuthenticationException("No token provided"));

        mockMvc.perform(post("/api/auth/logout"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("No token provided"))
                .andExpect(jsonPath("$.error").value("LOGOUT_FAILED"));
    }

    @Test
    void testRefreshTokenSuccess() throws Exception {
        LoginResponse refreshResponse = new LoginResponse();
        refreshResponse.setToken("new-jwt-token");
        refreshResponse.setUserType("CUSTOMER");
        refreshResponse.setUsername("testuser");
        refreshResponse.setIsNewUser(true);

        when(authService.refreshToken(any())).thenReturn(refreshResponse);

        mockMvc.perform(post("/api/auth/refresh")
                .header("Authorization", "Bearer jwt-token"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.token").value("new-jwt-token"))
                .andExpect(jsonPath("$.userType").value("CUSTOMER"))
                .andExpect(jsonPath("$.username").value("testuser"));
    }

    @Test
    void testRefreshTokenUnauthorized() throws Exception {
        when(authService.refreshToken(any()))
                .thenThrow(new AuthenticationException("Invalid or missing token"));

        mockMvc.perform(post("/api/auth/refresh")
                .header("Authorization", "Bearer invalid-token"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Invalid or missing token"))
                .andExpect(jsonPath("$.error").value("TOKEN_REFRESH_FAILED"));
    }

    @Test
    void testValidateTokenValid() throws Exception {
        when(authService.isTokenValid("jwt-token")).thenReturn(true);

        mockMvc.perform(get("/api/auth/validate")
                .header("Authorization", "Bearer jwt-token"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.valid").value(true));
    }

    @Test
    void testValidateTokenInvalid() throws Exception {
        when(authService.isTokenValid("invalid-token")).thenReturn(false);

        mockMvc.perform(get("/api/auth/validate")
                .header("Authorization", "Bearer invalid-token"))
                .andExpect(status().isUnauthorized())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.valid").value(false))
                .andExpect(jsonPath("$.error").value("Invalid or expired token"));
    }

    @Test
    void testValidateTokenNoToken() throws Exception {
        when(authService.isTokenValid(null)).thenReturn(false);

        mockMvc.perform(get("/api/auth/validate"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.valid").value(false))
                .andExpect(jsonPath("$.error").value("Invalid or expired token"));
    }
}
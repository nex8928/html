-- Loan Origination System Database Schema
-- PostgreSQL Database Creation Script

-- ===============================
-- AUTHENTICATION & USERS
-- ===============================

CREATE TABLE users (
    customer_id BIGINT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_new_user BOOLEAN DEFAULT true,
    activation_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE roles (
    role_id BIGINT PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL
);

CREATE TABLE members (
    member_id BIGINT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role_id BIGINT NOT NULL REFERENCES roles(role_id)
);

-- ===============================
-- LOOKUP TABLES
-- ===============================

CREATE TABLE gender_lookup (
    gender_id INTEGER PRIMARY KEY,
    gender_name VARCHAR(20) UNIQUE NOT NULL
);

CREATE TABLE marital_status_lookup (
    marital_status_id INTEGER PRIMARY KEY,
    status_name VARCHAR(30) UNIQUE NOT NULL
);

CREATE TABLE occupation_lookup (
    occupation_id INTEGER PRIMARY KEY,
    occupation_name VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE loan_status_lookup (
    status_id INTEGER PRIMARY KEY,
    status_name VARCHAR(50) UNIQUE NOT NULL,
    description VARCHAR(255)
);

CREATE TABLE document_types (
    document_type_id INTEGER PRIMARY KEY,
    type_name VARCHAR(100) UNIQUE NOT NULL
);

-- ===============================
-- CUSTOMER DETAILS
-- ===============================

CREATE TABLE personal_details (
    user_id BIGINT PRIMARY KEY REFERENCES users(customer_id),
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE,
    date_of_birth DATE NOT NULL,
    gender_id INTEGER REFERENCES gender_lookup(gender_id),
    marital_status_id INTEGER REFERENCES marital_status_lookup(marital_status_id),
    phone_number VARCHAR(15) NOT NULL,
    alternate_phone VARCHAR(15),
    current_address TEXT NOT NULL,
    permanent_address TEXT NOT NULL,
    aadhaar_number VARCHAR(12) UNIQUE,
    pan_number VARCHAR(10) UNIQUE,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE employment_details (
    user_id BIGINT PRIMARY KEY REFERENCES users(customer_id),
    occupation_id INTEGER REFERENCES occupation_lookup(occupation_id),
    employer_name VARCHAR(255),
    job_title VARCHAR(255),
    work_experience_years INTEGER,
    annual_income DECIMAL(15,2),
    employer_address VARCHAR(500),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ===============================
-- LOAN APPLICATION
-- ===============================

CREATE TABLE loan_applications (
    application_id BIGINT PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(customer_id),
    status_id INTEGER NOT NULL REFERENCES loan_status_lookup(status_id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE loan_details (
    application_id BIGINT PRIMARY KEY REFERENCES loan_applications(application_id),
    loan_type VARCHAR(100) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    interest_rate DECIMAL(5,2),
    tenure_months INTEGER,
    monthly_emi DECIMAL(15,2),
    maker_id BIGINT REFERENCES members(member_id),
    maker_approved_at TIMESTAMP,
    maker_comments TEXT,
    checker_id BIGINT REFERENCES members(member_id),
    checker_approved_at TIMESTAMP,
    checker_comments TEXT,
    rejection_reason TEXT,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE nominee_details (
    nominee_id BIGINT PRIMARY KEY,
    application_id BIGINT NOT NULL REFERENCES loan_applications(application_id),
    nominee_name VARCHAR(255) NOT NULL,
    relationship VARCHAR(100) NOT NULL,
    nominee_dob DATE,
    nominee_address VARCHAR(500),
    nominee_phone VARCHAR(15),
    nominee_email VARCHAR(255),
    nominee_aadhaar VARCHAR(12),
    nominee_pan VARCHAR(10),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ===============================
-- DOCUMENT MANAGEMENT
-- ===============================

CREATE TABLE user_documents (
    document_id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id BIGINT NOT NULL REFERENCES users(customer_id),
    document_type_id INTEGER NOT NULL REFERENCES document_types(document_type_id),
    file_path VARCHAR(500) NOT NULL,
    is_verified BOOLEAN DEFAULT false
);

CREATE TABLE loan_documents (
    loan_document_id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    application_id BIGINT NOT NULL REFERENCES loan_applications(application_id),
    document_type_id INTEGER NOT NULL REFERENCES document_types(document_type_id),
    file_path VARCHAR(500) NOT NULL,
    is_verified BOOLEAN DEFAULT false
);

-- ===============================
-- WORKFLOW & TRACKING
-- ===============================

CREATE TABLE application_status_history (
    history_id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    application_id BIGINT NOT NULL REFERENCES loan_applications(application_id),
    from_status_id INTEGER REFERENCES loan_status_lookup(status_id),
    to_status_id INTEGER NOT NULL REFERENCES loan_status_lookup(status_id),
    changed_by BIGINT REFERENCES members(member_id),
    changed_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE internal_notes (
    note_id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    application_id BIGINT NOT NULL REFERENCES loan_applications(application_id),
    member_id BIGINT NOT NULL REFERENCES members(member_id),
    note_content TEXT NOT NULL,
    note_type VARCHAR(50) DEFAULT 'GENERAL',
    is_confidential BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ===============================
-- INDEXES FOR PERFORMANCE
-- ===============================

-- User-related indexes
CREATE INDEX idx_personal_details_user_id ON personal_details(user_id);
CREATE UNIQUE INDEX idx_personal_details_aadhaar ON personal_details(aadhaar_number) WHERE aadhaar_number IS NOT NULL;
CREATE UNIQUE INDEX idx_personal_details_pan ON personal_details(pan_number) WHERE pan_number IS NOT NULL;

-- Application-related indexes
CREATE INDEX idx_loan_applications_user_id ON loan_applications(user_id);
CREATE INDEX idx_loan_applications_status ON loan_applications(status_id);

-- Document-related indexes
CREATE INDEX idx_user_documents_user_type ON user_documents(user_id, document_type_id);
CREATE INDEX idx_loan_documents_app_type ON loan_documents(application_id, document_type_id);

-- Workflow indexes
CREATE INDEX idx_status_history_application ON application_status_history(application_id);
CREATE INDEX idx_status_history_date ON application_status_history(changed_at);
CREATE INDEX idx_internal_notes_application ON internal_notes(application_id);

-- ===============================
-- SEED DATA
-- ===============================

-- Insert Roles
INSERT INTO roles (role_id, role_name) VALUES 
(1, 'CUSTOMER'),
(2, 'MAKER'),
(3, 'CHECKER'),
(4, 'ADMIN');

-- Insert Gender Options
INSERT INTO gender_lookup (gender_id, gender_name) VALUES 
(1, 'Male'),
(2, 'Female'),
(3, 'Other');

-- Insert Marital Status Options
INSERT INTO marital_status_lookup (marital_status_id, status_name) VALUES 
(1, 'Single'),
(2, 'Married'),
(3, 'Divorced'),
(4, 'Widowed');

-- Insert Occupation Types
INSERT INTO occupation_lookup (occupation_id, occupation_name) VALUES 
(1, 'Salaried Employee'),
(2, 'Self-Employed Professional'),
(3, 'Business Owner'),
(4, 'Freelancer'),
(5, 'Government Employee'),
(6, 'Retired'),
(7, 'Student'),
(8, 'Other');

-- Insert Loan Status Options
INSERT INTO loan_status_lookup (status_id, status_name, description) VALUES 
(1, 'DRAFT', 'Application in draft state'),
(2, 'SUBMITTED', 'Application submitted for review'),
(3, 'UNDER_REVIEW', 'Application being reviewed by maker'),
(4, 'MAKER_APPROVED', 'Approved by maker, pending checker review'),
(5, 'APPROVED', 'Final approval by checker'),
(6, 'REJECTED', 'Application rejected'),
(7, 'INCOMPLETE', 'Additional documents required'),
(8, 'CANCELLED', 'Application cancelled by customer');

-- Insert Document Types
INSERT INTO document_types (document_type_id, type_name) VALUES 
(1, 'Aadhaar Card'),
(2, 'PAN Card'),
(3, 'Passport'),
(4, 'Driving License'),
(5, 'Bank Statement'),
(6, 'Salary Slip'),
(7, 'ITR Document'),
(8, 'Employment Certificate'),
(9, 'Property Document'),
(10, 'Other');

-- Insert Sample Bank Members
INSERT INTO members (member_id, username, password_hash, role_id) VALUES 
(1, 'maker1', '$2a$10$dummy_hash_for_maker1', 2),
(2, 'checker1', '$2a$10$dummy_hash_for_checker1', 3),
(3, 'admin', '$2a$10$dummy_hash_for_admin', 4);

COMMIT;

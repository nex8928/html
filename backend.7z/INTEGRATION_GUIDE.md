# Frontend-Backend Integration Guide

## Overview
Your existing React frontend in the `TempWork` folder is now configured to integrate with your Spring Boot backend. This guide will help you get both services running together.

## Prerequisites
1. **Backend**: Java 17+, Maven, PostgreSQL
2. **Frontend**: Node.js 16+, npm

## Quick Start

### 1. Start Both Services
Run the provided batch file to start both services:
```bash
./start-development.bat
```

Or start them manually:

**Backend (Terminal 1):**
```bash
mvn spring-boot:run
```

**Frontend (Terminal 2):**
```bash
cd TempWork
npm start
```

### 2. Access the Application
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8080
- **API Documentation**: http://localhost:8080/swagger-ui.html

## Integration Features

### ✅ Already Configured
1. **CORS**: Backend allows requests from localhost:3000
2. **Proxy**: Frontend proxy configured for API calls
3. **Authentication**: JWT token handling in AuthContext
4. **API Service**: Centralized axios configuration
5. **Error Handling**: Automatic token refresh and error responses

### 🔧 API Endpoints Integration

#### Authentication
- `POST /api/auth/customer/register` - Customer registration
- `POST /api/auth/customer/login` - Customer login
- `POST /api/auth/member/login` - Bank member login

#### Loan Applications
- `GET /api/customer/applications` - Get user's applications
- `POST /api/customer/applications` - Submit new application
- `GET /api/customer/applications/{id}` - Get specific application
- `PUT /api/customer/applications/{id}` - Update application

#### Lookup Data
- `GET /api/lookup/genders` - Get gender options
- `GET /api/lookup/marital-statuses` - Get marital status options
- `GET /api/lookup/occupations` - Get occupation options

#### Admin/Testing
- `GET /api/admin/health` - Health check
- `POST /api/admin/initialize-data` - Initialize test data

## Testing the Integration

### 1. Connection Test
Visit the home page (http://localhost:3000) and click "Test Backend Connection" to verify the services are communicating.

### 2. User Registration
1. Go to http://localhost:3000/register
2. Create a new customer account
3. Login with the created credentials

### 3. Loan Application
1. After login, go to "Apply for Loan"
2. Fill out the multi-step form
3. Submit the application
4. Check the dashboard for the submitted application

## File Structure

### Frontend (TempWork/)
```
src/
├── components/
│   ├── Navbar.js
│   └── ConnectionTest.js
├── context/
│   └── AuthContext.js
├── pages/
│   ├── Home.js
│   ├── Login.js
│   ├── Register.js
│   ├── Dashboard.js
│   ├── LoanApplication.js
│   └── ApplicationStatus.js
├── services/
│   ├── api.js          # Axios configuration
│   └── loanService.js  # API service methods
└── utils/
    └── testConnection.js
```

### Backend (src/main/java/com/loanorigination/)
```
├── controller/
│   ├── AuthController.java
│   ├── CustomerController.java
│   ├── AdminController.java
│   └── LookupController.java
├── entity/
├── service/
├── repository/
└── config/
    └── SecurityConfig.java  # CORS configuration
```

## Environment Configuration

### Backend (application.properties)
```properties
server.port=8080
spring.datasource.url=jdbc:postgresql://localhost:5432/loan_origination_db
# ... other configurations
```

### Frontend (package.json)
```json
{
  "proxy": "http://localhost:8080"
}
```

## Troubleshooting

### Common Issues

1. **CORS Errors**
   - Ensure backend CORS is configured for `http://localhost:3000`
   - Check SecurityConfig.java

2. **Connection Refused**
   - Verify backend is running on port 8080
   - Check database connection
   - Ensure PostgreSQL is running

3. **Authentication Issues**
   - Check JWT token in localStorage
   - Verify token expiration
   - Check API interceptors

4. **API Errors**
   - Check browser network tab for actual error responses
   - Verify endpoint URLs match backend controllers
   - Check request/response formats

### Debug Steps
1. Check browser console for errors
2. Check network tab for API calls
3. Check backend logs for errors
4. Use the connection test on home page
5. Verify database has required tables and data

## Next Steps

1. **Test all features** - Registration, login, loan application, dashboard
2. **Add error boundaries** - Better error handling in React components
3. **Add loading states** - Improve user experience
4. **Add form validation** - Client-side validation for better UX
5. **Add notifications** - Toast notifications for success/error messages

## Support
If you encounter issues:
1. Check the browser console and network tab
2. Check backend application logs
3. Verify database connectivity
4. Use the built-in connection test feature
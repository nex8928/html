# 🏦 Loan Origination System - Full Stack Application

A complete loan origination system built with **Spring Boot** (backend) and **React** (frontend) that handles the entire loan application process from customer registration to loan disbursement.

## 🎯 What This System Does

This is a **digital loan processing platform** that replaces traditional paper-based loan applications with a streamlined online process.

### 👥 User Roles & Workflow

1. **CUSTOMERS** → Apply for loans, track status
2. **MAKERS** (Loan Officers) → Process and review applications  
3. **CHECKERS** (Senior Officers) → Final approval/rejection
4. **ADMINS** → System management and oversight

### 🔄 Complete Loan Workflow

```
Customer Registration → Loan Application → Document Upload → 
Maker Review → Checker Approval → Loan Disbursement
```

## 🏗️ Architecture

### Backend (Spring Boot)
- **Framework**: Spring Boot 3.1.5 with Java 17
- **Database**: PostgreSQL with JPA/Hibernate
- **Security**: JWT Authentication + Role-based access
- **API Documentation**: Swagger/OpenAPI 3
- **Architecture**: RESTful APIs with layered architecture

### Frontend (React)
- **Framework**: React 18 with functional components
- **UI Library**: React Bootstrap for responsive design
- **Routing**: React Router for SPA navigation
- **State Management**: Context API for authentication
- **HTTP Client**: Axios with interceptors

### Database Schema
- **Users & Roles**: Customer and staff management
- **Applications**: Loan application lifecycle
- **Documents**: File upload and management
- **Audit Trail**: Complete status history tracking
- **Lookup Tables**: Configurable system data

## 🚀 Quick Start

### 1. Prerequisites
```bash
# Install required software
Java 17+, Maven 3.6+, Node.js 16+, PostgreSQL 12+
```

### 2. Database Setup
```sql
CREATE DATABASE loan_origination_db;
```

### 3. Start Backend
```bash
cd C:\Users\Asus\Downloads\springboot\springboot
mvn spring-boot:run
```

### 4. Start Frontend
```bash
cd C:\Users\Asus\Downloads\springboot\springboot\TempWork
npm install
npm start
```

### 5. Initialize System Data
Visit: `http://localhost:8080/swagger-ui.html`
Execute: `POST /api/admin/initialize-data`

### 6. Access Application
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8080
- **API Docs**: http://localhost:8080/swagger-ui.html

## 🎮 How to Use

### For Customers
1. **Register**: Create account at http://localhost:3000/register
2. **Login**: Sign in to access dashboard
3. **Apply**: Fill out multi-step loan application
4. **Track**: Monitor application status in real-time
5. **Documents**: Upload required documents

### For Staff
1. **Login**: Use staff credentials (maker1/password123)
2. **Review**: Process submitted applications
3. **Approve/Reject**: Make lending decisions
4. **Notes**: Add internal comments and observations

### Default Credentials
- **Maker**: `maker1` / `password123`
- **Checker**: `checker1` / `password123`

## 🔧 Key Features

### ✅ Implemented Features
- **User Authentication** (JWT-based)
- **Role-based Access Control**
- **Multi-step Loan Application Form**
- **Application Status Tracking**
- **Admin Dashboard**
- **Responsive UI Design**
- **API Documentation**
- **Database Integration**
- **CORS Configuration**
- **Connection Testing**

### 🚧 Ready for Extension
- **Document Upload System**
- **Email Notifications**
- **Loan Calculator**
- **Payment Schedules**
- **Advanced Reporting**
- **Mobile App Integration**

## 📊 System Statistics

### Backend Components
- **17 Entity Classes** (Users, Applications, Documents, etc.)
- **17 Repository Interfaces** (Data access layer)
- **Multiple Service Classes** (Business logic)
- **REST Controllers** (API endpoints)
- **Security Configuration** (JWT + CORS)
- **Swagger Documentation** (Interactive API docs)

### Frontend Components
- **6 Main Pages** (Home, Login, Register, Dashboard, etc.)
- **Authentication Context** (Global state management)
- **Protected Routes** (Route guards)
- **Responsive Design** (Bootstrap components)
- **API Integration** (Axios with interceptors)

## 🗄️ Database Tables Created
When you run the application, Hibernate automatically creates:

- `users` - Customer accounts
- `members` - Staff accounts  
- `roles` - User roles (CUSTOMER, MAKER, CHECKER)
- `loan_applications` - Main application data
- `loan_details` - Loan-specific information
- `personal_details` - Customer personal info
- `employment_details` - Employment information
- `nominee_details` - Beneficiary information
- `loan_documents` - Document metadata
- `application_status_history` - Audit trail
- `internal_notes` - Staff comments
- Plus lookup tables for genders, occupations, etc.

## 🎯 Real-World Applications

This system can be used by:
- **Banks** for personal/business loans
- **Credit Unions** for member lending
- **NBFCs** for specialized lending
- **Microfinance Institutions**
- **Online Lending Platforms**

## 📈 Business Benefits

- **Faster Processing**: Digital workflow vs paper-based
- **Better Tracking**: Real-time status updates
- **Compliance**: Complete audit trail
- **Risk Management**: Multi-level approval process
- **Customer Experience**: Online application and tracking
- **Cost Reduction**: Reduced manual processing
- **Scalability**: Handle more applications efficiently

## 🔍 Technical Highlights

### Security
- JWT token-based authentication
- Password encryption (BCrypt)
- Role-based access control
- CORS configuration for cross-origin requests
- Protected API endpoints

### Performance
- Connection pooling (HikariCP)
- Lazy loading for entities
- Efficient database queries
- Frontend code splitting
- Responsive design for all devices

### Maintainability
- Clean architecture with separation of concerns
- Comprehensive API documentation
- Consistent error handling
- Modular frontend components
- Configuration-driven setup

## 📞 Support & Troubleshooting

### Common Issues
1. **Port conflicts**: Kill processes using ports 8080/3000
2. **Database connection**: Verify PostgreSQL is running
3. **Maven build fails**: Clear target folder and retry
4. **CORS errors**: Check backend CORS configuration

### Getting Help
1. Check the `FULLSTACK_SETUP.md` guide
2. Use the connection test feature on homepage
3. Check browser console for frontend errors
4. Check backend logs for API errors
5. Use Swagger UI to test API endpoints

---

## 🎉 Congratulations!

You now have a **production-ready loan origination system** that demonstrates:
- Full-stack development with modern technologies
- Enterprise-level architecture and security
- Real-world business process automation
- Professional UI/UX design
- Comprehensive documentation

This system serves as an excellent foundation for building more advanced financial applications! 🚀
# 🏦 Loan Origination System - Full Stack Setup Guide

This guide will help you set up and run the complete loan origination system with Spring Boot backend and React frontend.

## 📁 Project Structure
```
springboot/
├── src/                          # Spring Boot Backend
│   ├── main/java/com/loanorigination/
│   └── main/resources/
├── TempWork/                     # React Frontend
│   ├── src/
│   ├── public/
│   └── package.json
├── pom.xml                       # Backend dependencies
└── FULLSTACK_SETUP.md           # This file
```

## 🛠️ Prerequisites

### 1. Install Required Software
- **Java 17** or higher
- **Maven 3.6+**
- **Node.js 16+** and **npm**
- **PostgreSQL 12+**
- **pgAdmin** (optional, for database management)

### 2. Verify Installations
```bash
java -version
mvn -version
node -version
npm -version
psql --version
```

## 🗄️ Database Setup

### 1. Start PostgreSQL Service
```bash
# Windows
net start postgresql-x64-17

# Or check if running
sc query postgresql-x64-17
```

### 2. Create Database
```sql
-- Connect to PostgreSQL as postgres user
CREATE DATABASE loan_origination_db;
```

### 3. Update Database Configuration
Check `src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/loan_origination_db
spring.datasource.username=postgres
spring.datasource.password=password  # Update with your password
```

## 🚀 Backend Setup (Spring Boot)

### 1. Navigate to Backend Directory
```bash
cd C:\Users\Asus\Downloads\springboot\springboot
```

### 2. Clean and Install Dependencies
```bash
# If Maven clean fails due to file locks:
taskkill /f /im java.exe
rmdir /s /q target

# Then run:
mvn clean install -DskipTests
```

### 3. Start Backend Server
```bash
mvn spring-boot:run
```

### 4. Verify Backend is Running
- Backend runs on: `http://localhost:8080`
- API Documentation: `http://localhost:8080/swagger-ui.html`
- Health check: `http://localhost:8080/api/admin/health`

### 5. Initialize System Data
**Important**: After backend starts, initialize lookup data:
```bash
# Using curl
curl -X POST http://localhost:8080/api/admin/initialize-data

# Or visit Swagger UI and execute the endpoint
```

## 🎨 Frontend Setup (React)

### 1. Navigate to Frontend Directory
```bash
cd C:\Users\Asus\Downloads\springboot\springboot\TempWork
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Start Frontend Development Server
```bash
npm start
```

### 4. Verify Frontend is Running
- Frontend runs on: `http://localhost:3000`
- Automatically proxies API calls to backend on port 8080

## 🔗 Full Stack Integration

### 1. CORS Configuration
The backend is configured to accept requests from `http://localhost:3000`

### 2. API Proxy
The frontend `package.json` includes:
```json
"proxy": "http://localhost:8080"
```

### 3. Authentication Flow
- JWT tokens are stored in localStorage
- Axios interceptors handle token attachment
- Protected routes redirect to login if not authenticated

## 🧪 Testing the Full Stack

### 1. Register a New Customer
1. Go to `http://localhost:3000`
2. Click "Register"
3. Fill out the form
4. Should redirect to dashboard after successful registration

### 2. Staff Login
1. Go to `http://localhost:3000/login`
2. Switch to "Staff Login" tab
3. Use credentials: `maker1` / `password123` or `checker1` / `password123`

### 3. Apply for Loan
1. Login as customer
2. Go to "Apply for Loan"
3. Fill out the multi-step form
4. Submit application

### 4. Admin Functions
1. Login as staff member
2. Go to `/admin` (if you have admin role)
3. View and manage applications

## 📊 Available Features

### Customer Features
- ✅ User Registration & Login
- ✅ Loan Application (Multi-step form)
- ✅ Application Status Tracking
- ✅ Dashboard with Application Summary

### Staff Features
- ✅ Staff Login (Maker/Checker)
- ✅ Application Review
- ✅ Status Updates
- ✅ Admin Dashboard

### System Features
- ✅ JWT Authentication
- ✅ Role-based Access Control
- ✅ Database Integration
- ✅ API Documentation (Swagger)
- ✅ Responsive UI (Bootstrap)

## 🔧 Troubleshooting

### Backend Issues
```bash
# Port 8080 in use
netstat -ano | findstr :8080
taskkill /PID <process_id> /F

# Database connection failed
# Check PostgreSQL is running and credentials are correct

# Maven build fails
# Close IDE, kill Java processes, delete target folder
```

### Frontend Issues
```bash
# Port 3000 in use
# Kill the process or use different port
npm start -- --port 3001

# Dependencies issues
rm -rf node_modules package-lock.json
npm install

# API calls failing
# Check backend is running on port 8080
# Check CORS configuration
```

### Database Issues
```bash
# Check PostgreSQL status
sc query postgresql-x64-17

# Reset database
DROP DATABASE loan_origination_db;
CREATE DATABASE loan_origination_db;
```

## 🎯 Default Credentials

### Staff Accounts (Pre-configured)
- **Maker**: `maker1` / `password123`
- **Checker**: `checker1` / `password123`

### Customer Accounts
- Register new accounts through the frontend
- Or create via API: `POST /api/auth/customer/register`

## 📝 API Endpoints

### Authentication
- `POST /api/auth/customer/register` - Customer registration
- `POST /api/auth/customer/login` - Customer login
- `POST /api/auth/member/login` - Staff login

### Admin
- `POST /api/admin/initialize-data` - Initialize system data
- `GET /api/admin/health` - Health check

### Applications (To be implemented)
- `POST /api/customer/applications` - Submit loan application
- `GET /api/customer/applications` - Get customer applications
- `PUT /api/maker/applications/{id}` - Update application (Maker)
- `PUT /api/checker/applications/{id}` - Approve/Reject (Checker)

## 🚀 Next Steps

1. **Complete API Implementation**: Add remaining CRUD operations for loan applications
2. **File Upload**: Implement document upload functionality
3. **Email Notifications**: Add email alerts for status changes
4. **Advanced Features**: Add loan calculator, payment schedules, etc.
5. **Testing**: Add unit and integration tests
6. **Deployment**: Configure for production deployment

## 📞 Support

If you encounter issues:
1. Check this guide first
2. Verify all prerequisites are installed
3. Check console logs for error messages
4. Ensure both backend and frontend are running
5. Test API endpoints using Swagger UI

---

**🎉 Congratulations!** You now have a fully functional loan origination system running locally!
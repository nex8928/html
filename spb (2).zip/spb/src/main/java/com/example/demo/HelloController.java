package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/")
    public String hello() {
        return "Hello, Spring Boot! Application is working correctly.";
    }

    @GetMapping("/api/hello")
    public String apiHello() {
        return "Hello from API!";
    }

    @GetMapping("/test")
    public String test() {
        return "Test endpoint is working!";
    }
}
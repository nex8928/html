# Frontend Authentication Integration Guide

This document explains how to integrate the frontend with the backend authentication system.

## Overview

The authentication system provides:
- Customer and Member login functionality
- JWT token management with automatic refresh
- Role-based routing and access control
- Persistent authentication state
- Automatic logout on token expiration

## Files Added/Modified

### New Files
- `src/services/authService.js` - Core authentication service
- `src/hooks/useAuth.js` - React hook for authentication state
- `src/utils/routeUtils.js` - Route protection utilities
- `src/components/LogoutButton.js` - Reusable logout component
- `.env` - Environment configuration

### Modified Files
- `src/CustomerLogin.js` - Enhanced with backend integration
- `src/MemberLogin.js` - Enhanced with backend integration

## Setup Instructions

### 1. Install Dependencies (if needed)
The integration uses standard React hooks and fetch API, so no additional dependencies are required.

### 2. Environment Configuration
Create a `.env` file in the root directory:
```env
REACT_APP_API_URL=http://localhost:8080/api
REACT_APP_ENV=development
REACT_APP_DEBUG=true
```

### 3. Wrap Your App with AuthProvider
Update your main App.js or index.js:

```javascript
import { AuthProvider } from './hooks/useAuth';

function App() {
  return (
    <AuthProvider>
      {/* Your existing app components */}
    </AuthProvider>
  );
}
```

### 4. Use Authentication in Components

#### Basic Usage
```javascript
import { useAuth } from './hooks/useAuth';

function MyComponent() {
  const { user, isAuthenticated, logout } = useAuth();
  
  if (!isAuthenticated) {
    return <div>Please log in</div>;
  }
  
  return (
    <div>
      <h1>Welcome, {user.username}!</h1>
      <button onClick={logout}>Logout</button>
    </div>
  );
}
```

#### Login Form Integration
```javascript
import { useAuth } from './hooks/useAuth';

function LoginForm() {
  const { login, loading, error } = useAuth();
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await login({ username, password }, 'customer');
      // Redirect will happen automatically
    } catch (error) {
      // Error is handled by the hook
    }
  };
  
  return (
    <form onSubmit={handleSubmit}>
      {/* Form fields */}
      {error && <div className="error">{error}</div>}
      <button disabled={loading}>
        {loading ? 'Logging in...' : 'Login'}
      </button>
    </form>
  );
}
```

## API Integration

### Authentication Endpoints
- `POST /api/auth/customer/login` - Customer login
- `POST /api/auth/member/login` - Member login
- `POST /api/auth/customer/register` - Customer registration
- `POST /api/auth/logout` - Logout
- `POST /api/auth/refresh` - Token refresh
- `GET /api/auth/validate` - Token validation
- `GET /api/auth/profile` - User profile

### Request/Response Format

#### Login Request
```javascript
{
  "username": "user123",
  "password": "password123"
}
```

#### Login Response
```javascript
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "userType": "CUSTOMER",
  "username": "user123",
  "isNewUser": true,
  "redirectUrl": "/customer/profile-setup",
  "message": "Login successful"
}
```

#### Error Response
```javascript
{
  "message": "Invalid username or password",
  "error": "AUTHENTICATION_FAILED",
  "status": 401,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

## Token Management

### Automatic Token Refresh
The system automatically refreshes tokens every 50 minutes (assuming 1-hour expiration):

```javascript
// This happens automatically when using AuthProvider
authService.setupTokenRefresh();
```

### Manual Token Operations
```javascript
import authService from './services/authService';

// Check if user is authenticated
const isAuth = authService.isAuthenticated();

// Get current user data
const userData = authService.getUserData();

// Get stored token
const token = authService.getToken();

// Validate token
const isValid = await authService.validateToken();

// Refresh token
const newToken = await authService.refreshToken();
```

## Role-Based Access Control

### Route Protection
```javascript
import { ProtectedRoute } from './utils/routeUtils';

function App() {
  return (
    <Routes>
      <Route path="/customer/login" element={<CustomerLogin />} />
      <Route path="/member/login" element={<MemberLogin />} />
      
      <Route path="/customer/dashboard" element={
        <ProtectedRoute requiredRole="customer">
          <CustomerDashboard />
        </ProtectedRoute>
      } />
      
      <Route path="/member/dashboard" element={
        <ProtectedRoute requiredRole="member">
          <MemberDashboard />
        </ProtectedRoute>
      } />
    </Routes>
  );
}
```

### Role Checking
```javascript
import { useAuth } from './hooks/useAuth';

function MyComponent() {
  const { user, isCustomer, isMember } = useAuth();
  
  return (
    <div>
      {isCustomer && <CustomerFeatures />}
      {isMember && <MemberFeatures />}
      {user?.userType === 'CHECKER' && <AdminFeatures />}
    </div>
  );
}
```

## Error Handling

### Global Error Handling
```javascript
import { useAuth } from './hooks/useAuth';

function ErrorBoundary() {
  const { error, clearError } = useAuth();
  
  if (error) {
    return (
      <div className="error-banner">
        <span>{error}</span>
        <button onClick={clearError}>Dismiss</button>
      </div>
    );
  }
  
  return null;
}
```

### Handling Authentication Errors
```javascript
// The auth service automatically handles:
// - Token expiration (redirects to login)
// - Network errors (shows error message)
// - Invalid credentials (shows error message)
// - Server errors (shows generic error)
```

## Logout Functionality

### Using the LogoutButton Component
```javascript
import LogoutButton from './components/LogoutButton';

function Header() {
  return (
    <header>
      <nav>
        {/* Navigation items */}
        <LogoutButton variant="link" />
      </nav>
    </header>
  );
}
```

### Manual Logout
```javascript
import { useAuth } from './hooks/useAuth';

function MyComponent() {
  const { logout } = useAuth();
  
  const handleLogout = async () => {
    await logout();
    // User will be redirected automatically
  };
  
  return <button onClick={handleLogout}>Sign Out</button>;
}
```

## Testing the Integration

### 1. Start the Backend
```bash
cd springboot
mvn spring-boot:run
```

### 2. Start the Frontend
```bash
cd TempWork
npm start
```

### 3. Test Login Flow
1. Navigate to `http://localhost:3000/customer/login`
2. Enter valid credentials
3. Verify redirect to appropriate dashboard
4. Test logout functionality
5. Verify token refresh (check browser dev tools)

### 4. Test Member Login
1. Navigate to `http://localhost:3000/member/login`
2. Enter valid member credentials
3. Verify redirect to member dashboard

## Troubleshooting

### Common Issues

#### CORS Errors
- Ensure backend CORS is configured for `http://localhost:3000`
- Check that the backend is running on port 8080

#### Token Issues
- Check browser localStorage for stored tokens
- Verify token format in network requests
- Check backend JWT configuration

#### Network Errors
- Verify API_URL in .env file
- Check that backend endpoints are accessible
- Use browser dev tools to inspect network requests

### Debug Mode
Enable debug logging by setting `REACT_APP_DEBUG=true` in .env file.

## Security Considerations

1. **Token Storage**: Tokens are stored in localStorage (consider httpOnly cookies for production)
2. **HTTPS**: Use HTTPS in production
3. **Token Expiration**: Tokens automatically refresh before expiration
4. **Logout**: Always call logout to invalidate server-side sessions
5. **Error Handling**: Don't expose sensitive error details to users

## Next Steps

1. Add password reset functionality
2. Implement remember me feature
3. Add biometric authentication
4. Implement session timeout warnings
5. Add audit logging for authentication events
# Logout Functionality Implementation

## Overview

This document describes the complete logout functionality implementation for the member-customer login system, including backend API endpoints, frontend integration, and security features.

## Backend Implementation

### 1. Logout Endpoint

**Endpoint:** `POST /api/auth/logout`

**Features:**
- Token invalidation through blacklisting
- User type-based redirect URL determination
- Proper error handling for missing tokens
- CORS support for frontend integration

**Request:**
```http
POST /api/auth/logout
Authorization: Bearer <jwt-token>
Content-Type: application/json
```

**Response:**
```json
{
  "message": "Logout successful",
  "redirectUrl": "/customer/login",
  "success": true
}
```

### 2. Token Blacklisting

The system implements a simple but effective token blacklisting mechanism:

```java
// In AuthService.java
private final Set<String> blacklistedTokens = ConcurrentHashMap.newKeySet();

public LogoutResponse logout(HttpServletRequest request) {
    String token = extractTokenFromRequest(request);
    if (token == null) {
        throw new AuthenticationException("No token provided");
    }
    
    // Add token to blacklist
    blacklistedTokens.add(token);
    
    // Determine redirect URL based on user type
    String redirectUrl = "/";
    try {
        String userType = jwtUtil.extractUserType(token);
        if ("CUSTOMER".equals(userType)) {
            redirectUrl = "/customer/login";
        } else {
            redirectUrl = "/member/login";
        }
    } catch (Exception e) {
        // If token is invalid, use default redirect
    }
    
    return new LogoutResponse("Logout successful", redirectUrl, true);
}
```

### 3. Token Validation

All protected endpoints check for blacklisted tokens:

```java
private boolean isTokenBlacklisted(String token) {
    return blacklistedTokens.contains(token);
}

public boolean isTokenValid(String token) {
    return token != null && !isTokenBlacklisted(token) && jwtUtil.validateToken(token);
}
```

### 4. Security Configuration

The logout endpoint is configured as publicly accessible but requires a valid token:

```java
// In SecurityConfig.java
.requestMatchers("/api/auth/logout").permitAll()
```

## Frontend Implementation

### 1. Authentication Service

**File:** `TempWork/src/services/authService.js`

Key features:
- Centralized authentication management
- Token storage in localStorage
- Automatic token cleanup on logout
- API error handling

```javascript
async logout() {
    try {
        const token = this.getToken();
        if (token) {
            // Call backend logout endpoint
            await fetch(`${API_BASE_URL}/logout`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
            });
        }
    } catch (error) {
        console.error('Logout API call failed:', error);
        // Continue with local logout even if API call fails
    } finally {
        // Always clear local storage
        this.clearAuthData();
    }
}
```

### 2. useAuth Hook

**File:** `TempWork/src/hooks/useAuth.js`

Provides React components with authentication state and methods:

```javascript
const logout = useCallback(async () => {
    try {
        setIsLoading(true);
        await authService.logout();
    } catch (error) {
        console.error('Logout error:', error);
        // Continue with logout even if API call fails
    } finally {
        setUser(null);
        setIsAuthenticated(false);
        setIsLoading(false);
    }
}, []);
```

### 3. Logout Button Component

**File:** `TempWork/src/components/LogoutButton.js`

Reusable logout button with loading states and proper error handling:

```javascript
const handleLogout = async () => {
    setIsLoading(true);
    try {
        await logout();
        
        // Redirect to appropriate login page based on user type
        const loginUrl = user?.userType === 'CUSTOMER' ? '/customer/login' : '/member/login';
        navigate(loginUrl);
    } catch (error) {
        console.error('Logout failed:', error);
        // Even if logout fails, redirect to login
        navigate('/');
    } finally {
        setIsLoading(false);
    }
};
```

### 4. Updated Login Components

Both `CustomerLogin.js` and `MemberLogin.js` have been updated to use the new authentication service:

- Centralized authentication logic
- Consistent error handling
- Proper redirect URL determination
- Integration with useAuth hook

## Security Features

### 1. Token Invalidation

- Tokens are immediately blacklisted upon logout
- Blacklisted tokens cannot be used for any authenticated requests
- Token validation checks blacklist before JWT validation

### 2. Graceful Degradation

- Frontend continues logout process even if backend call fails
- Local storage is always cleared regardless of API response
- Users are redirected to appropriate login pages

### 3. CORS Configuration

- Proper CORS headers for frontend integration
- Support for multiple development origins
- Credentials support for authenticated requests

### 4. Error Handling

- Comprehensive error responses with proper HTTP status codes
- Detailed error messages for debugging
- Fallback behavior for edge cases

## Testing

### 1. Backend Tests

Existing tests in `AuthControllerTest.java` and `AuthServiceTest.java` cover:
- Successful logout with valid token
- Logout failure without token
- Token invalidation verification
- Redirect URL determination

### 2. Integration Tests

**File:** `TempWork/test-logout-integration.js`

Comprehensive Node.js test that verifies:
- Complete registration → login → logout → token invalidation cycle
- Error handling for missing tokens
- Proper HTTP status codes
- Token blacklisting functionality

### 3. Frontend Tests

**File:** `TempWork/test-frontend-integration.html`

Interactive HTML test page that verifies:
- Authentication service functionality
- Login/logout cycle
- Token validation
- Frontend component integration

## API Endpoints Summary

| Endpoint | Method | Auth Required | Description |
|----------|--------|---------------|-------------|
| `/api/auth/customer/login` | POST | No | Customer login |
| `/api/auth/member/login` | POST | No | Member login |
| `/api/auth/logout` | POST | Yes | Logout (invalidate token) |
| `/api/auth/profile` | GET | Yes | Get user profile |
| `/api/auth/validate` | GET | Yes | Validate token |
| `/api/auth/refresh` | POST | Yes | Refresh token |

## Usage Examples

### Frontend Usage

```javascript
import { useAuth } from './hooks/useAuth';

function MyComponent() {
    const { logout, user, isAuthenticated } = useAuth();
    
    const handleLogout = async () => {
        try {
            await logout();
            // User will be redirected automatically
        } catch (error) {
            console.error('Logout failed:', error);
        }
    };
    
    return (
        <div>
            {isAuthenticated && (
                <button onClick={handleLogout}>
                    Logout {user?.username}
                </button>
            )}
        </div>
    );
}
```

### Direct API Usage

```javascript
// Logout API call
const response = await fetch('http://localhost:8080/api/auth/logout', {
    method: 'POST',
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
    },
});

const data = await response.json();
console.log(data.redirectUrl); // "/customer/login" or "/member/login"
```

## Configuration

### Backend Configuration

No additional configuration required. The logout functionality uses:
- In-memory token blacklisting (suitable for single-instance deployments)
- JWT token validation
- Existing security configuration

### Frontend Configuration

Update the API base URL in `authService.js` if needed:

```javascript
const API_BASE_URL = 'http://localhost:8080/api/auth';
```

## Deployment Considerations

### Production Recommendations

1. **Token Blacklisting**: Consider using Redis or database-backed token blacklisting for multi-instance deployments
2. **Token Expiry**: Implement automatic cleanup of expired blacklisted tokens
3. **Monitoring**: Add logging for logout events and security monitoring
4. **Rate Limiting**: Implement rate limiting for logout endpoints

### Security Best Practices

1. Always validate tokens on the backend
2. Clear all client-side storage on logout
3. Implement proper CORS policies
4. Use HTTPS in production
5. Consider implementing logout from all devices functionality

## Troubleshooting

### Common Issues

1. **Token still valid after logout**: Check if token blacklisting is working properly
2. **CORS errors**: Verify CORS configuration includes frontend origin
3. **Redirect not working**: Check user type detection in logout response
4. **Frontend not updating**: Ensure useAuth hook state is properly updated

### Debug Steps

1. Check browser network tab for API calls
2. Verify token is being sent in Authorization header
3. Check backend logs for authentication errors
4. Test with the provided integration test files
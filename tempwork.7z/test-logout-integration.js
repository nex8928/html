// Integration test for logout functionality
const API_BASE_URL = 'http://localhost:8080/api/auth';

async function testLogoutIntegration() {
  console.log('🧪 Testing Logout Integration...\n');

  try {
    // Step 1: Register a new customer
    console.log('1️⃣ Registering new customer...');
    const registerResponse = await fetch(`${API_BASE_URL}/customer/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: `testuser_${Date.now()}`,
        password: 'password123',
      }),
    });

    if (!registerResponse.ok) {
      throw new Error(`Registration failed: ${registerResponse.status}`);
    }

    const registerData = await registerResponse.json();
    console.log('✅ Registration successful');
    console.log(`   Token: ${registerData.token.substring(0, 20)}...`);
    console.log(`   User Type: ${registerData.userType}`);
    console.log(`   Redirect URL: ${registerData.redirectUrl}\n`);

    const token = registerData.token;

    // Step 2: Verify token works by getting profile
    console.log('2️⃣ Verifying token works...');
    const profileResponse = await fetch(`${API_BASE_URL}/profile`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    if (!profileResponse.ok) {
      throw new Error(`Profile request failed: ${profileResponse.status}`);
    }

    const profileData = await profileResponse.json();
    console.log('✅ Token verification successful');
    console.log(`   Username: ${profileData.username}`);
    console.log(`   User Type: ${profileData.userType}\n`);

    // Step 3: Test logout
    console.log('3️⃣ Testing logout...');
    const logoutResponse = await fetch(`${API_BASE_URL}/logout`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    if (!logoutResponse.ok) {
      throw new Error(`Logout failed: ${logoutResponse.status}`);
    }

    const logoutData = await logoutResponse.json();
    console.log('✅ Logout successful');
    console.log(`   Message: ${logoutData.message}`);
    console.log(`   Success: ${logoutData.success}`);
    console.log(`   Redirect URL: ${logoutData.redirectUrl}\n`);

    // Step 4: Verify token is invalidated
    console.log('4️⃣ Verifying token invalidation...');
    const invalidProfileResponse = await fetch(`${API_BASE_URL}/profile`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    if (invalidProfileResponse.ok) {
      throw new Error('Token should be invalid after logout!');
    }

    console.log('✅ Token properly invalidated');
    console.log(`   Status: ${invalidProfileResponse.status} (Expected: 401)\n`);

    // Step 5: Test logout without token
    console.log('5️⃣ Testing logout without token...');
    const noTokenLogoutResponse = await fetch(`${API_BASE_URL}/logout`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (noTokenLogoutResponse.ok) {
      throw new Error('Logout should fail without token!');
    }

    console.log('✅ Logout properly rejected without token');
    console.log(`   Status: ${noTokenLogoutResponse.status} (Expected: 401)\n`);

    console.log('🎉 All logout integration tests passed!');
    return true;

  } catch (error) {
    console.error('❌ Test failed:', error.message);
    return false;
  }
}

// Run the test
testLogoutIntegration().then(success => {
  process.exit(success ? 0 : 1);
});
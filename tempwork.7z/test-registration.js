// Test script to verify registration functionality
const API_BASE_URL = 'http://localhost:8080/api/auth';

async function testRegistration() {
  console.log('🧪 Testing Customer Registration...\n');

  try {
    // Test registration
    console.log('1️⃣ Testing customer registration...');
    const registerResponse = await fetch(`${API_BASE_URL}/customer/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: `testuser_${Date.now()}`,
        password: 'password123',
      }),
    });

    if (!registerResponse.ok) {
      const errorData = await registerResponse.json();
      throw new Error(`Registration failed: ${errorData.message || registerResponse.status}`);
    }

    const registerData = await registerResponse.json();
    console.log('✅ Registration successful!');
    console.log(`   Username: ${registerData.username}`);
    console.log(`   User Type: ${registerData.userType}`);
    console.log(`   Is New User: ${registerData.isNewUser}`);
    console.log(`   Redirect URL: ${registerData.redirectUrl}`);
    console.log(`   Token: ${registerData.token.substring(0, 20)}...\n`);

    console.log('🎉 Registration test passed!');
    return true;

  } catch (error) {
    console.error('❌ Registration test failed:', error.message);
    return false;
  }
}

// Run the test
testRegistration().then(success => {
  process.exit(success ? 0 : 1);
});
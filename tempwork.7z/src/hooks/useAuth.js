import { useState, useEffect, useCallback } from 'react';
import authService from '../services/authService';

export const useAuth = () => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize authentication state
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const userData = authService.getUserData();
        const token = authService.getToken();

        if (userData && token) {
          // Validate token with backend
          const isValid = await authService.validateToken();
          if (isValid) {
            setUser(userData);
            setIsAuthenticated(true);
          } else {
            // Token is invalid, clear auth data
            authService.clearAuthData();
            setUser(null);
            setIsAuthenticated(false);
          }
        } else {
          setUser(null);
          setIsAuthenticated(false);
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        authService.clearAuthData();
        setUser(null);
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, []);

  // Login customer
  const loginCustomer = useCallback(async (credentials) => {
    try {
      setIsLoading(true);
      const response = await authService.loginCustomer(credentials);
      
      const userData = {
        username: response.username,
        userType: response.role,
        isNewUser: response.isNewUser,
      };

      setUser(userData);
      setIsAuthenticated(true);
      
      return response;
    } catch (error) {
      console.error('Customer login error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Login member
  const loginMember = useCallback(async (credentials) => {
    try {
      setIsLoading(true);
      const response = await authService.loginMember(credentials);
      
      const userData = {
        username: response.username,
        userType: response.role,
        isNewUser: response.isNewUser,
      };

      setUser(userData);
      setIsAuthenticated(true);
      
      return response;
    } catch (error) {
      console.error('Member login error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Logout
  const logout = useCallback(async () => {
    try {
      setIsLoading(true);
      await authService.logout();
    } catch (error) {
      console.error('Logout error:', error);
      // Continue with logout even if API call fails
    } finally {
      setUser(null);
      setIsAuthenticated(false);
      setIsLoading(false);
    }
  }, []);

  // Refresh token
  const refreshToken = useCallback(async () => {
    try {
      const response = await authService.refreshToken();
      
      const userData = {
        username: response.username,
        userType: response.role,
        isNewUser: response.isNewUser,
      };

      setUser(userData);
      setIsAuthenticated(true);
      
      return response;
    } catch (error) {
      console.error('Token refresh error:', error);
      setUser(null);
      setIsAuthenticated(false);
      throw error;
    }
  }, []);

  // Get user profile
  const getUserProfile = useCallback(async () => {
    try {
      const profile = await authService.getUserProfile();
      return profile;
    } catch (error) {
      console.error('Get user profile error:', error);
      throw error;
    }
  }, []);

  // Check if user has required role
  const hasRole = useCallback((requiredRole) => {
    if (!user || !user.userType) return false;
    
    // Define role hierarchy
    const roleHierarchy = {
      'CUSTOMER': ['customer'],
      'MAKER': ['member', 'maker'],
      'CHECKER': ['member', 'maker', 'checker', 'admin'],
    };

    const userRoles = roleHierarchy[user.userType] || [];
    return userRoles.includes(requiredRole.toLowerCase());
  }, [user]);

  // Get redirect URL based on user type and status
  const getRedirectUrl = useCallback(() => {
    if (!user) return '/';

    if (user.userType === 'CUSTOMER') {
      return user.isNewUser ? '/customer-profile' : '/user-dashboard';
    } else if (user.userType === 'MAKER') {
      return '/maker-dashboard';
    } else if (user.userType === 'CHECKER') {
      return '/checker-dashboard';
    }
    
    return '/';
  }, [user]);

  // Get logout redirect URL
  const getLogoutRedirectUrl = useCallback(() => {
    return authService.getLogoutRedirectUrl(user?.userType);
  }, [user]);

  return {
    user,
    isAuthenticated,
    isLoading,
    loginCustomer,
    loginMember,
    logout,
    refreshToken,
    getUserProfile,
    hasRole,
    getRedirectUrl,
    getLogoutRedirectUrl,
  };
};
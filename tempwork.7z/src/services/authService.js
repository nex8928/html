// Authentication service for handling login, logout, and token management
const API_BASE_URL = 'http://localhost:8080/api/auth';

class AuthService {
  constructor() {
    this.token = localStorage.getItem('auth_token');
    this.userData = this.getUserData();
  }

  // Login customer
  async loginCustomer(credentials) {
    try {
      const response = await fetch(`${API_BASE_URL}/customer/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Login failed');
      }

      // Store authentication data
      this.setAuthData(data);
      return data;
    } catch (error) {
      console.error('Customer login error:', error);
      throw error;
    }
  }

  // Login member
  async loginMember(credentials) {
    try {
      const response = await fetch(`${API_BASE_URL}/member/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Login failed');
      }

      // Store authentication data
      this.setAuthData(data);
      return data;
    } catch (error) {
      console.error('Member login error:', error);
      throw error;
    }
  }

  // Logout user
  async logout() {
    try {
      const token = this.getToken();
      if (token) {
        // Call backend logout endpoint
        await fetch(`${API_BASE_URL}/logout`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        });
      }
    } catch (error) {
      console.error('Logout API call failed:', error);
      // Continue with local logout even if API call fails
    } finally {
      // Always clear local storage
      this.clearAuthData();
    }
  }

  // Get user profile
  async getUserProfile() {
    try {
      const token = this.getToken();
      if (!token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE_URL}/profile`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to get user profile');
      }

      return data;
    } catch (error) {
      console.error('Get user profile error:', error);
      throw error;
    }
  }

  // Refresh token
  async refreshToken() {
    try {
      const token = this.getToken();
      if (!token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE_URL}/refresh`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Token refresh failed');
      }

      // Update stored authentication data
      this.setAuthData(data);
      return data;
    } catch (error) {
      console.error('Token refresh error:', error);
      // If refresh fails, logout user
      this.clearAuthData();
      throw error;
    }
  }

  // Validate token
  async validateToken() {
    try {
      const token = this.getToken();
      if (!token) {
        return false;
      }

      const response = await fetch(`${API_BASE_URL}/validate`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();
      return response.ok && data.valid;
    } catch (error) {
      console.error('Token validation error:', error);
      return false;
    }
  }

  // Set authentication data in localStorage
  setAuthData(data) {
    this.token = data.token;
    this.userData = {
      username: data.username,
      userType: data.role,
      isNewUser: data.isNewUser,
    };

    localStorage.setItem('auth_token', data.token);
    localStorage.setItem('user_data', JSON.stringify(this.userData));
  }

  // Clear authentication data
  clearAuthData() {
    this.token = null;
    this.userData = null;
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_data');
  }

  // Get stored token
  getToken() {
    return this.token || localStorage.getItem('auth_token');
  }

  // Get stored user data
  getUserData() {
    if (this.userData) {
      return this.userData;
    }

    const storedData = localStorage.getItem('user_data');
    if (storedData) {
      try {
        this.userData = JSON.parse(storedData);
        return this.userData;
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        localStorage.removeItem('user_data');
      }
    }
    return null;
  }

  // Check if user is authenticated
  isAuthenticated() {
    const token = this.getToken();
    const userData = this.getUserData();
    return !!(token && userData);
  }

  // Get redirect URL after logout based on user type
  getLogoutRedirectUrl(userType) {
    return userType === 'CUSTOMER' ? '/customer' : '/member';
  }

  // Add token to request headers
  getAuthHeaders() {
    const token = this.getToken();
    return token ? { 'Authorization': `Bearer ${token}` } : {};
  }

  // Make authenticated API request
  async makeAuthenticatedRequest(url, options = {}) {
    const token = this.getToken();
    if (!token) {
      throw new Error('No authentication token');
    }

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      ...options.headers,
    };

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      // If token is invalid, try to refresh
      if (response.status === 401) {
        try {
          await this.refreshToken();
          // Retry the request with new token
          const newHeaders = {
            ...headers,
            'Authorization': `Bearer ${this.getToken()}`,
          };
          return await fetch(url, {
            ...options,
            headers: newHeaders,
          });
        } catch (refreshError) {
          // If refresh fails, logout and redirect
          this.clearAuthData();
          window.location.href = '/';
          throw refreshError;
        }
      }

      return response;
    } catch (error) {
      console.error('Authenticated request error:', error);
      throw error;
    }
  }
}

// Create singleton instance
const authService = new AuthService();

export default authService;
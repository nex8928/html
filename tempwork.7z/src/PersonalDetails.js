import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import ProgressBar from "./ProgressBar";
import {
  ArrowRight,
  Upload,
  User,
  FileText,
  Bot,
  ArrowLeft,
} from "lucide-react";

const PersonalDetails = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    middleName: "",
    lastName: "",
    gender: "",
    phoneNumber: "",
    emailAddress: "",
    maritalStatus: "",
    aadhaarNumber: "",
    panNumber: "",
    currentAddress: "",
    permanentAddress: "",
    attachments: {
      photograph: null,
      aadhaarCard: null,
      panCard: null,
      governmentID: null, // Passport or Voter ID or Driver License
    },
  });
  const [isSameAddress, setIsSameAddress] = useState(false);
  const [activeTab, setActiveTab] = useState("personal"); // 'personal' or 'attachments'

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleFileChange = (e, attachmentName) => {
    const file = e.target.files[0];
    setFormData((prevData) => ({
      ...prevData,
      attachments: {
        ...prevData.attachments,
        [attachmentName]: file,
      },
    }));
  };

  const handleAddressToggle = () => {
    setIsSameAddress(!isSameAddress);
    if (!isSameAddress) {
      setFormData((prevData) => ({
        ...prevData,
        permanentAddress: prevData.currentAddress,
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Personal Details Submitted:", formData);
    // In a real app, you would save this data and move to the next step.
  };

  const renderPersonalDetails = () => (
    <section>
      <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
        <User className="w-5 h-5 text-indigo-600" />
        Applicant Information
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label
            htmlFor="firstName"
            className="block text-sm font-medium text-gray-700"
          >
            First Name
          </label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            placeholder="John"
            value={formData.firstName}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
        <div>
          <label
            htmlFor="middleName"
            className="block text-sm font-medium text-gray-700"
          >
            Middle Name (Optional)
          </label>
          <input
            type="text"
            id="middleName"
            name="middleName"
            placeholder="Smith"
            value={formData.middleName}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
        <div>
          <label
            htmlFor="lastName"
            className="block text-sm font-medium text-gray-700"
          >
            Last Name
          </label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            placeholder="Doe"
            value={formData.lastName}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
      </div>
      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="gender"
            className="block text-sm font-medium text-gray-700"
          >
            Gender
          </label>
          <select
            id="gender"
            name="gender"
            value={formData.gender}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          >
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div>
          <label
            htmlFor="maritalStatus"
            className="block text-sm font-medium text-gray-700"
          >
            Marital Status
          </label>
          <select
            id="maritalStatus"
            name="maritalStatus"
            value={formData.maritalStatus}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          >
            <option value="">Select Marital Status</option>
            <option value="single">Single</option>
            <option value="married">Married</option>
            <option value="divorced">Divorced</option>
            <option value="widowed">Widowed</option>
          </select>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="phoneNumber"
            className="block text-sm font-medium text-gray-700"
          >
            Phone Number
          </label>
          <input
            type="tel"
            id="phoneNumber"
            name="phoneNumber"
            placeholder="(123) 456-7890"
            value={formData.phoneNumber}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
        <div>
          <label
            htmlFor="emailAddress"
            className="block text-sm font-medium text-gray-700"
          >
            Email Address
          </label>
          <input
            type="email"
            id="emailAddress"
            name="emailAddress"
            placeholder="john.doe@example.com"
            value={formData.emailAddress}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
      </div>
      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="aadhaarNumber"
            className="block text-sm font-medium text-gray-700"
          >
            Aadhaar Card Number
          </label>
          <input
            type="text"
            id="aadhaarNumber"
            name="aadhaarNumber"
            placeholder="XXXX XXXX XXXX"
            value={formData.aadhaarNumber}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
        <div>
          <label
            htmlFor="panNumber"
            className="block text-sm font-medium text-gray-700"
          >
            PAN Card Number
          </label>
          <input
            type="text"
            id="panNumber"
            name="panNumber"
            placeholder="ABCDE1234F"
            value={formData.panNumber}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
      </div>
      <div className="mt-4 space-y-4">
        <div>
          <label
            htmlFor="currentAddress"
            className="block text-sm font-medium text-gray-700"
          >
            Current Address
          </label>
          <textarea
            id="currentAddress"
            name="currentAddress"
            placeholder="Current Address"
            rows="3"
            value={formData.currentAddress}
            onChange={handleInputChange}
            className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          ></textarea>
        </div>
        <div className="flex items-center">
          <input
            id="same-address"
            name="same-address"
            type="checkbox"
            checked={isSameAddress}
            onChange={handleAddressToggle}
            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
          />
          <label
            htmlFor="same-address"
            className="ml-2 block text-sm text-gray-900"
          >
            Permanent Address is the same as Current Address
          </label>
        </div>
        {!isSameAddress && (
          <div>
            <label
              htmlFor="permanentAddress"
              className="block text-sm font-medium text-gray-700"
            >
              Permanent Address
            </label>
            <textarea
              id="permanentAddress"
              name="permanentAddress"
              placeholder="Permanent Address"
              rows="3"
              value={formData.permanentAddress}
              onChange={handleInputChange}
              className="mt-1 w-full p-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            ></textarea>
          </div>
        )}
      </div>
    </section>
  );

  const renderAttachments = () => (
    <section>
      <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
        <Upload className="w-5 h-5 text-indigo-600" />
        Required Attachments
      </h2>
      <p className="text-sm text-gray-600 mb-4">
        Please upload the required documents below. Accepted formats: PDF, JPG,
        PNG.
      </p>

      <div className="space-y-4">
        {["photograph", "aadhaarCard", "panCard", "governmentID"].map(
          (docName, index) => (
            <div
              key={index}
              className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 bg-gray-50 rounded-md border border-gray-200"
            >
              <label className="block text-sm font-medium text-gray-700 sm:w-1/3">
                {docName === "governmentID"
                  ? "Passport/Voter ID/Driver License"
                  : docName
                      .replace(/([A-Z])/g, " $1")
                      .replace(/^./, (str) => str.toUpperCase())}
              </label>
              <div className="mt-2 sm:mt-0 sm:w-2/3 flex items-center gap-2">
                <input
                  type="file"
                  id={docName}
                  name={docName}
                  onChange={(e) => handleFileChange(e, docName)}
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                />
                {formData.attachments[docName] && (
                  <span className="text-xs text-gray-500 flex-shrink-0">
                    {formData.attachments[docName].name}
                  </span>
                )}
              </div>
            </div>
          )
        )}
      </div>
    </section>
  );
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
        <ProgressBar currentStep={1} />
      <button
        onClick={() => navigate(-1)}
        className="fixed top-4 left-4 z-50 flex items-center gap-2 px-4 py-2 rounded-full bg-white shadow-lg text-gray-700 hover:bg-gray-200 transition-colors transform hover:scale-105"
      >
        <ArrowLeft className="w-5 h-5" />
        Back
      </button>
      <div className="flex flex-col max-w-[88rem] md:flex-row w-full gap-8 items-start">
        {/* Main form container */}
        <div className="w-full md:w-3/4 bg-white rounded-2xl shadow-2xl overflow-hidden p-6 sm:p-10">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
            Personal Details
          </h1>
          <p className="text-sm text-gray-600 mb-6">
            Let's start with your personal and contact information.
          </p>

          <div className="flex border-b border-gray-200 mb-8">
            <button
              type="button"
              onClick={() => setActiveTab("personal")}
              className={`flex-1 py-3 px-1 text-center font-medium text-sm transition-colors duration-200 border-b-2 ${
                activeTab === "personal"
                  ? "border-indigo-600 text-indigo-600"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              <span className="flex items-center justify-center gap-2">
                <User className="w-4 h-4" /> Personal Details
              </span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("attachments")}
              className={`flex-1 py-3 px-1 text-center font-medium text-sm transition-colors duration-200 border-b-2 ${
                activeTab === "attachments"
                  ? "border-indigo-600 text-indigo-600"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              <span className="flex items-center justify-center gap-2">
                <FileText className="w-4 h-4" /> Attachments
              </span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="min-h-[600px]" // Added min-h to prevent vertical jump
              >
                {activeTab === "personal"
                  ? renderPersonalDetails()
                  : renderAttachments()}
              </motion.div>
            </AnimatePresence>

            <div className="flex justify-end mt-6">
              <Link
                to="/employmentdetails"
                className="inline-flex items-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all duration-200"
              >
                Next
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </div>
          </form>
        </div>

        {/* Floating Chatbot Companion */}
        <div className="hidden md:block md:w-2/5 h-[80vh] bg-white rounded-2xl shadow-2xl p-6 border border-gray-200 overflow-y-auto sticky top-4">
          <div className="flex items-center gap-3 text-indigo-600 mb-4 border-b pb-4">
            <Bot className="w-6 h-6" />
            <h3 className="text-lg font-bold">Your Loan Companion</h3>
          </div>
          <div className="text-gray-700 space-y-4">
            <p>Hi there! I'm here to help you with your loan application.</p>
            <p>
              Feel free to ask me any questions you have about the process or
              the documents you need to submit.
            </p>
            <div className="p-4 bg-indigo-50 rounded-lg">
              <p className="text-sm">
                This is a placeholder for a live chatbot interface.
              </p>
              <p className="text-sm mt-2 text-indigo-800">
                Possible functionality: Answer FAQs, guide through form fields,
                check loan eligibility in real-time.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalDetails;

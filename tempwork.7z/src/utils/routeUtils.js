// Route protection utilities
export const RouteUtils = {
  // Check if user can access a route
  canAccessRoute: (requiredRole, userRole) => {
    if (!requiredRole) return true; // Public route
    if (!userRole) return false; // Not authenticated

    // Define role hierarchy and permissions
    const rolePermissions = {
      'CUSTOMER': ['customer'],
      'MAKER': ['member', 'maker'],
      'CHECKER': ['member', 'maker', 'checker', 'admin'],
    };

    const userPermissions = rolePermissions[userRole] || [];
    return userPermissions.includes(requiredRole.toLowerCase());
  },

  // Get redirect URL based on user type and status
  getRedirectUrl: (userType, isNewUser) => {
    if (userType === 'CUSTOMER') {
      return isNewUser ? '/customer/profile-setup' : '/customer/dashboard';
    } else if (userType === 'MAKER') {
      return '/maker/dashboard';
    } else if (userType === 'CHECKER') {
      return '/checker/dashboard';
    }
    return '/';
  },

  // Check if user should be redirected after login
  shouldRedirect: (currentPath, userType, isNewUser) => {
    const loginPaths = ['/customer/login', '/member/login', '/'];
    
    if (loginPaths.includes(currentPath)) {
      return true;
    }

    // Redirect new customers to profile setup
    if (userType === 'CUSTOMER' && isNewUser && !currentPath.includes('/customer/profile')) {
      return true;
    }

    return false;
  },

  // Get appropriate dashboard URL
  getDashboardUrl: (userType) => {
    switch (userType) {
      case 'CUSTOMER':
        return '/customer/dashboard';
      case 'MAKER':
        return '/maker/dashboard';
      case 'CHECKER':
        return '/checker/dashboard';
      default:
        return '/';
    }
  },

  // Get login URL based on user type
  getLoginUrl: (userType) => {
    return userType === 'CUSTOMER' ? '/customer/login' : '/member/login';
  },
};

// Get user data from localStorage
const getUserData = () => {
  const storedData = localStorage.getItem('user_data');
  if (storedData) {
    try {
      return JSON.parse(storedData);
    } catch (error) {
      console.error('Error parsing stored user data:', error);
      localStorage.removeItem('user_data');
    }
  }
  return null;
};

// Check if user is authenticated
const isAuthenticated = () => {
  const token = localStorage.getItem('auth_token');
  const userData = getUserData();
  return !!(token && userData);
};

// Protected Route Component
export const ProtectedRoute = ({ children, requiredRole, fallbackPath = '/' }) => {
  const userData = getUserData();
  const authenticated = isAuthenticated();

  if (!authenticated) {
    // Redirect to appropriate login page
    const loginUrl = requiredRole === 'customer' ? '/customer/login' : '/member/login';
    window.location.href = loginUrl;
    return null;
  }

  if (!RouteUtils.canAccessRoute(requiredRole, userData?.userType)) {
    // Redirect to appropriate dashboard or fallback
    const dashboardUrl = RouteUtils.getDashboardUrl(userData?.userType) || fallbackPath;
    window.location.href = dashboardUrl;
    return null;
  }

  return children;
};

// Auto-redirect component for authenticated users
export const AuthRedirect = ({ children }) => {
  const userData = getUserData();
  const authenticated = isAuthenticated();

  if (authenticated && userData) {
    const redirectUrl = RouteUtils.getRedirectUrl(userData.userType, userData.isNewUser);
    window.location.href = redirectUrl;
    return null;
  }

  return children;
};

export default RouteUtils;
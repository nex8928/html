import React, { useState } from 'react';
import { LogOut, Loader } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const LogoutButton = ({ className = '', variant = 'button', children }) => {
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    setIsLoading(true);
    try {
      // Get current user data to determine redirect URL
      const userData = JSON.parse(localStorage.getItem('user_data') || '{}');
      const token = localStorage.getItem('auth_token');
      
      // Call backend logout endpoint if token exists
      if (token) {
        try {
          const response = await fetch('http://localhost:8080/api/auth/logout', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
          });

          const data = await response.json();
          
          // Use redirect URL from backend response if available
          if (response.ok && data.redirectUrl) {
            // Clear local storage
            localStorage.removeItem('auth_token');
            localStorage.removeItem('user_data');
            
            navigate(data.redirectUrl);
            return;
          }
        } catch (error) {
          console.error('Logout API call failed:', error);
          // Continue with local logout even if API call fails
        }
      }
      
      // Fallback: Clear local storage and redirect based on user type
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user_data');
      
      // Determine redirect URL based on user type
      const loginUrl = userData.userType === 'CUSTOMER' ? '/customer/login' : '/member/login';
      navigate(loginUrl);
      
    } catch (error) {
      console.error('Logout failed:', error);
      // Even if logout fails, clear storage and redirect to home
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user_data');
      navigate('/');
    } finally {
      setIsLoading(false);
    }
  };

  if (variant === 'link') {
    return (
      <button
        onClick={handleLogout}
        disabled={isLoading}
        className={`flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800 transition-colors disabled:opacity-50 ${className}`}
      >
        {isLoading ? (
          <Loader className="h-4 w-4 animate-spin" />
        ) : (
          <LogOut className="h-4 w-4" />
        )}
        {children || 'Logout'}
      </button>
    );
  }

  return (
    <button
      onClick={handleLogout}
      disabled={isLoading}
      className={`flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
    >
      {isLoading ? (
        <Loader className="h-4 w-4 animate-spin" />
      ) : (
        <LogOut className="h-4 w-4" />
      )}
      {children || 'Logout'}
    </button>
  );
};

export default LogoutButton;